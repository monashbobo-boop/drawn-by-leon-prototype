/**
 * Service details as photo cards.
 *
 * In the editor this is a plain Group ("details-cards") holding one Group per detail
 * ("detail-card"): an Image, a Heading (the item) and a Paragraph (the details).
 * Leon changes the photo, the words, adds or removes a card right there.
 * The outer group's second class picks the layout on the page:
 *   details-deck  A stack of photo cards with the details beside it and two arrows.
 *                 Tap the stack or an arrow and the top card goes to the back.
 *   details-pile  A pile of photo cards. Tap it and it opens: the chosen photo grows,
 *                 its details sit beside it, the others line up as small photos.
 *                 Tap a small one to swap it in (GSAP Flip).
 * Without the script the cards simply show side by side, as in the editor.
 */
( function () {
	'use strict';

	var REDUCE = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	var COLOURS = [ 'is-yellow', 'is-paper', 'is-navy' ];

	function readRows( group ) {
		return [].slice.call( group.children ).filter( function ( c ) {
			return c.classList.contains( 'detail-card' );
		} ).map( function ( c ) {
			var img = c.querySelector( 'img' );
			var label = c.querySelector( '.detail-card__label' ) || c.querySelector( 'h2, h3, h4, h5, h6, strong' );
			var text = c.querySelector( '.detail-card__text' ) || c.querySelector( 'p:not(.detail-card__label)' );
			return {
				label: label ? label.textContent.trim() : '',
				html: text ? text.innerHTML : '',
				src: img ? img.currentSrc || img.src : '',
				srcset: img ? img.getAttribute( 'srcset' ) || '' : '',
				alt: img ? img.getAttribute( 'alt' ) || '' : '',
			};
		} ).filter( function ( r ) {
			return r.label;
		} );
	}

	function makeCard( row, i, tag ) {
		var c = document.createElement( tag || 'div' );
		c.className = 'dc-card ' + COLOURS[ i % COLOURS.length ];
		if ( row.src ) {
			var im = document.createElement( 'img' );
			im.src = row.src;
			if ( row.srcset ) {
				im.srcset = row.srcset;
				im.sizes = '(min-width: 900px) 360px, 60vw';
			}
			im.alt = row.alt;
			im.loading = 'lazy';
			im.decoding = 'async';
			c.appendChild( im );
		}
		var l = document.createElement( 'span' );
		l.className = 'dc-card__label';
		l.textContent = row.label;
		c.appendChild( l );
		return c;
	}

	function infoPanel( extraTools ) {
		var info = document.createElement( 'div' );
		info.className = 'dc-info';
		info.setAttribute( 'aria-live', 'polite' );
		info.innerHTML = '<h3 class="dc-label"></h3><div class="dc-text"></div>' +
			'<div class="dc-tools"><button type="button" class="dc-prev" aria-label="Previous">&larr;</button>' +
			'<button type="button" class="dc-next" aria-label="Next">&rarr;</button>' + ( extraTools || '' ) + '</div>';
		return info;
	}

	function fillInfo( info, rows, i, animate ) {
		info.querySelector( '.dc-label' ).textContent = rows[ i ].label;
		info.querySelector( '.dc-text' ).innerHTML = rows[ i ].html;
		if ( animate && ! REDUCE ) {
			info.classList.remove( 'is-changing' );
			void info.offsetWidth;
			info.classList.add( 'is-changing' );
		}
	}

	/* ---------- Deck: stack beside the details ---------- */
	function setupDeck( fig ) {
		var rows = readRows( fig );
		if ( rows.length < 2 ) {
			return;
		}
		var n = rows.length;
		var order = rows.map( function ( _, i ) {
			return i;
		} );
		var deck = document.createElement( 'div' );
		deck.className = 'dc-deck';
		var stack = document.createElement( 'button' );
		stack.type = 'button';
		stack.className = 'dc-stack';
		stack.setAttribute( 'aria-label', 'Show the next detail' );
		var cards = rows.map( function ( r, i ) {
			var c = makeCard( r, i );
			stack.appendChild( c );
			return c;
		} );
		var info = infoPanel();
		deck.appendChild( stack );
		deck.appendChild( info );
		fig.parentNode.insertBefore( deck, fig.nextSibling );
		fig.classList.add( 'is-enhanced' );

		var busy = false;
		function place() {
			order.forEach( function ( idx, pos ) {
				var c = cards[ idx ];
				c.setAttribute( 'data-pos', pos < 3 ? pos : 'rest' );
				c.style.zIndex = n - pos;
			} );
			fillInfo( info, rows, order[ 0 ], true );
		}
		function step( dir ) {
			if ( busy ) {
				return;
			}
			if ( dir > 0 ) {
				var top = cards[ order[ 0 ] ];
				if ( REDUCE ) {
					order.push( order.shift() );
					place();
					return;
				}
				busy = true;
				top.classList.add( 'is-leaving' );
				setTimeout( function () {
					order.push( order.shift() );
					top.classList.remove( 'is-leaving' );
					place();
					busy = false;
				}, 320 );
			} else {
				// Back: the last card comes back onto the top along the same path it left by.
				order.unshift( order.pop() );
				var back = cards[ order[ 0 ] ];
				if ( REDUCE ) {
					place();
					return;
				}
				busy = true;
				back.classList.add( 'is-leaving', 'no-anim' );
				place();
				void back.offsetWidth;
				back.classList.remove( 'no-anim' );
				requestAnimationFrame( function () {
					back.classList.remove( 'is-leaving' );
				} );
				setTimeout( function () {
					busy = false;
				}, 380 );
			}
		}
		stack.addEventListener( 'click', function () {
			step( 1 );
		} );
		info.querySelector( '.dc-next' ).addEventListener( 'click', function () {
			step( 1 );
		} );
		info.querySelector( '.dc-prev' ).addEventListener( 'click', function () {
			step( -1 );
		} );
		deck.addEventListener( 'keydown', function ( e ) {
			if ( e.key === 'ArrowRight' ) {
				step( 1 );
			} else if ( e.key === 'ArrowLeft' ) {
				step( -1 );
			}
		} );
		place();
		info.classList.remove( 'is-changing' );
	}

	/* ---------- Pile: opens into one big card and a row of small ones ---------- */
	function setupPile( fig ) {
		var rows = readRows( fig );
		if ( rows.length < 2 ) {
			return;
		}
		var gsap = window.gsap;
		var Flip = window.Flip;
		var hasFlip = !! ( gsap && Flip );
		if ( hasFlip ) {
			gsap.registerPlugin( Flip );
		}
		var n = rows.length;
		var order = rows.map( function ( _, i ) {
			return i;
		} );
		var opened = false;
		var busy = false;

		var root = document.createElement( 'div' );
		root.className = 'dc-pile';
		var frames = rows.map( function ( r, i ) {
			var b = makeCard( r, i, 'button' );
			b.type = 'button';
			b.classList.add( 'dc-frame' );
			b.addEventListener( 'click', function () {
				if ( ! opened ) {
					open( i );
				} else {
					choose( i );
				}
			} );
			root.appendChild( b );
			return b;
		} );
		var info = infoPanel( '<button type="button" class="dc-close" aria-label="Stack the cards back up">&times;</button>' );
		root.appendChild( info );
		fig.parentNode.insertBefore( root, fig.nextSibling );
		fig.classList.add( 'is-enhanced' );
		// Without a character beside it, the pile takes the full width (heading on top).
		// With one (an image "details-mascot" in the same columns) it stays in its column.
		var cols = fig.closest( '.wp-block-columns' );
		if ( cols ) {
			cols.classList.add( cols.querySelector( '.details-mascot' ) ? 'has-details-mascot' : 'has-details-pile' );
		}

		info.querySelector( '.dc-prev' ).addEventListener( 'click', function () {
			choose( order[ n - 1 ] );
		} );
		info.querySelector( '.dc-next' ).addEventListener( 'click', function () {
			choose( order[ 1 ] );
		} );
		info.querySelector( '.dc-close' ).addEventListener( 'click', close );

		function layout() {
			var W = root.clientWidth;
			var narrow = W < 600;
			var H;
			frames.forEach( function ( f, i ) {
				var hero = opened && order[ 0 ] === i;
				f.classList.toggle( 'is-hero', hero );
				f.classList.toggle( 'is-small', opened && ! hero );
				f.tabIndex = ! opened ? ( order[ 0 ] === i ? 0 : -1 ) : ( hero ? -1 : 0 );
				f.setAttribute( 'aria-label', opened ? 'Show ' + rows[ i ].label : 'Open the service details, ' + n + ' cards' );
			} );

			if ( ! opened ) {
				var pw = Math.min( 250, W * 0.6 );
				var ph = pw * 1.2;
				order.forEach( function ( idx, slot ) {
					var f = frames[ idx ];
					var rot = ( slot % 2 ? 1 : -1 ) * Math.min( slot, 3 ) * 3.5;
					f.style.width = pw + 'px';
					f.style.height = ph + 'px';
					f.style.left = ( W - pw ) / 2 + slot * 5 + 'px';
					f.style.top = 16 + slot * 7 + 'px';
					f.style.transform = 'rotate(' + rot + 'deg)';
					f.style.zIndex = n - slot;
				} );
				root.style.height = ph + 50 + 'px';
				return;
			}

			var heroW, heroH, heroX, tW, tH, gap = 10, railTop, railX;
			if ( narrow ) {
				// Phone: big photo on top, the small photos in a row under it, words below.
				heroW = W;
				// Never taller than about three quarters of the screen (phones held sideways).
				heroH = Math.min( W * 1.05, 460, Math.max( 240, window.innerHeight * 0.75 ) );
				heroX = 0;
				tW = Math.min( 72, ( W - gap * ( n - 2 ) ) / ( n - 1 ) );
				tH = tW;
				railTop = heroH + 18;
			} else {
				heroW = Math.min( 330, W * ( W < 760 ? 0.36 : 0.32 ) );
				heroH = heroW * 1.2;
				heroX = W - heroW;
				tW = Math.min( 76, Math.max( 56, W * 0.075 ) );
				tH = tW;
				railX = 0;
				railTop = Math.max( 0, ( heroH - ( ( n - 1 ) * tH + ( n - 2 ) * gap ) ) / 2 );
			}
			order.forEach( function ( idx, slot ) {
				var f = frames[ idx ];
				f.style.transform = 'none';
				if ( slot === 0 ) {
					f.style.left = heroX + 'px';
					f.style.top = '0px';
					f.style.width = heroW + 'px';
					f.style.height = heroH + 'px';
					f.style.zIndex = n + 1;
				} else if ( narrow ) {
					f.style.left = ( slot - 1 ) * ( tW + gap ) + 'px';
					f.style.top = railTop + 'px';
					f.style.width = tW + 'px';
					f.style.height = tH + 'px';
					f.style.zIndex = n - slot;
				} else {
					f.style.left = railX + 'px';
					f.style.top = railTop + ( slot - 1 ) * ( tH + gap ) + 'px';
					f.style.width = tW + 'px';
					f.style.height = tH + 'px';
					f.style.zIndex = n - slot;
				}
			} );
			if ( narrow ) {
				info.style.left = '0px';
				info.style.width = W + 'px';
				info.style.top = railTop + tH + 26 + 'px';
				info.style.transform = 'none';
				H = railTop + tH + 26 + info.offsetHeight + 10;
			} else {
				var infoX = tW + Math.max( 36, W * 0.05 );
				info.style.left = infoX + 'px';
				info.style.width = heroX - infoX - Math.max( 36, W * 0.05 ) + 'px';
				info.style.transform = 'none';
				// Centred on the big photo, but never above the top of the photos
				// (long text in a narrow column used to run into the heading).
				var infoH = info.offsetHeight;
				var infoTop = Math.max( 0, ( heroH - infoH ) / 2 );
				info.style.top = infoTop + 'px';
				H = Math.max( heroH, railTop + ( n - 1 ) * tH + ( n - 2 ) * gap, infoTop + infoH ) + 16;
			}
			root.style.height = H + 'px';
		}

		function animate( change, opts ) {
			if ( busy ) {
				return;
			}
			if ( ! hasFlip || REDUCE ) {
				change();
				layout();
				return;
			}
			busy = true;
			var state = Flip.getState( frames );
			change();
			layout();
			Flip.from( state, Object.assign( {
				duration: 0.65,
				ease: 'power3.inOut',
				onComplete: function () {
					busy = false;
				},
			}, opts || {} ) );
		}

		// Every move keeps the cards in their order: the picked card comes to the
		// front and the ones before it go to the back of the row. Arrows, taps on a
		// small card and the keyboard all move the same way.
		function bringToFront( i ) {
			while ( order[ 0 ] !== i ) {
				order.push( order.shift() );
			}
		}

		function open( first ) {
			animate( function () {
				opened = true;
				root.classList.add( 'is-open' );
				bringToFront( first );
				fillInfo( info, rows, order[ 0 ], true );
			}, { stagger: 0.035 } );
		}

		function choose( i ) {
			if ( i === order[ 0 ] ) {
				return;
			}
			animate( function () {
				bringToFront( i );
				fillInfo( info, rows, order[ 0 ], true );
			} );
		}

		function close() {
			animate( function () {
				opened = false;
				root.classList.remove( 'is-open' );
			}, { stagger: { each: 0.03, from: 'end' } } );
			frames[ order[ 0 ] ].focus( { preventScroll: true } );
		}

		root.addEventListener( 'keydown', function ( e ) {
			if ( ! opened ) {
				return;
			}
			if ( e.key === 'Escape' ) {
				close();
			} else if ( e.key === 'ArrowRight' || e.key === 'ArrowDown' ) {
				e.preventDefault();
				choose( order[ 1 ] );
			} else if ( e.key === 'ArrowLeft' || e.key === 'ArrowUp' ) {
				e.preventDefault();
				choose( order[ n - 1 ] );
			}
		} );

		var t;
		window.addEventListener( 'resize', function () {
			clearTimeout( t );
			t = setTimeout( layout, 120 );
		} );
		layout();
	}

	function init() {
		document.querySelectorAll( '.details-cards.details-deck' ).forEach( setupDeck );
		document.querySelectorAll( '.details-cards.details-pile' ).forEach( setupPile );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
