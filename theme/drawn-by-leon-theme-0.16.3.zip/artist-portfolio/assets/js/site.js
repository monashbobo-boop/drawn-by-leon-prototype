/**
 * Small page helpers. Both read plain blocks Leon can edit, and both leave the
 * page usable without JS.
 *
 * 1. Guest calculator: a group with class "guest-calc" gets a guests slider and a
 *    black-and-white / colour switch, and shows how long to book.
 * 2. Form switch: buttons linking to #event and #photo inside a "form-switch"
 *    group show one enquiry form at a time.
 * 3. Portfolio filter: buttons linking to #all or a gallery's anchor (#live,
 *    #live-bw, #from-photos, #digital) inside a "work-filter" group show one
 *    gallery (or all) in the "works-grid". "Live in colour" opens first. Drawings
 *    come in pages of 8, upright pages before wide ones; "View more" adds a page.
 * 4. Card stack: groups "stack-card" inside a "card-stack" group pile up and fan
 *    out when scrolled into view. On phones, tap the top card to see the next.
 * 5. Reveal rows: a "reveal-row" group's head opens its "reveal-row__panel".
 * 6. Doodle drop: images inside "doodle-drop__pile" fall into a heap when the
 *    area scrolls into view. Tap one to make it hop.
 * 7. Rotating gallery: a gallery with the class "is-rotator" shows its first three
 *    drawings; every few seconds all three change at once to the next three drawings
 *    from the gallery. Add as many drawings to the gallery as you like.
 * 9. Menu: the link to the page you are on gets the class "is-current".
 * 8. Crossfade and Slide galleries: a gallery with the "Crossfade" style shows one
 *    picture at a time, each fading into the next; with the "Slide" style the
 *    pictures run side by side as a strip that keeps moving left (home hero photos).
 */
( function () {
	'use strict';

	/* ---------- Guest calculator ---------- */
	var RATES = { bw: 13.5, colour: 9 }; // people per hour, middle of Leon's ranges (12–15 and 8–10)
	var MIN_HOURS = 2;

	function hoursFor( guests, style ) {
		var h = guests / RATES[ style ];
		return Math.max( MIN_HOURS, Math.ceil( h * 2 ) / 2 );
	}

	function setupCalc( box ) {
		if ( box.getAttribute( 'data-ready' ) ) {
			return;
		}
		box.setAttribute( 'data-ready', '1' );
		var ui = document.createElement( 'div' );
		ui.className = 'guest-calc__ui';
		ui.innerHTML =
			'<label class="guest-calc__label" for="gc-guests">How many guests?</label>' +
			'<div class="guest-calc__row"><input id="gc-guests" type="range" min="10" max="200" step="5" value="60">' +
			'<output class="guest-calc__guests" for="gc-guests">60</output></div>' +
			'<div class="guest-calc__switch" role="radiogroup" aria-label="Drawing style">' +
				'<button type="button" role="radio" aria-checked="true" data-style="bw">Black &amp; white</button>' +
				'<button type="button" role="radio" aria-checked="false" data-style="colour">Colour</button>' +
			'</div>' +
			'<p class="guest-calc__result" aria-live="polite"></p>';
		box.appendChild( ui );

		var range = ui.querySelector( 'input' );
		var out = ui.querySelector( 'output' );
		var result = ui.querySelector( '.guest-calc__result' );
		var style = 'bw';

		function render() {
			var g = +range.value;
			out.textContent = g;
			var h = hoursFor( g, style );
			var drawn = Math.round( h * RATES[ style ] );
			result.innerHTML = '<strong>' + h + ' hours</strong> <span>About ' + Math.min( g, drawn ) +
				' people drawn in ' + ( style === 'bw' ? 'black and white' : 'colour' ) +
				( drawn < g ? ', so most of your guests get one.' : ', enough for everyone who wants one.' ) + '</span>';
		}
		range.addEventListener( 'input', render );
		ui.querySelectorAll( '[data-style]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				style = b.getAttribute( 'data-style' );
				ui.querySelectorAll( '[data-style]' ).forEach( function ( x ) {
					x.setAttribute( 'aria-checked', x === b ? 'true' : 'false' );
				} );
				render();
			} );
		} );
		render();
	}

	/* ---------- Form switch ---------- */
	var forms = {};

	function showForm( which ) {
		if ( ! forms[ which ] ) {
			return;
		}
		Object.keys( forms ).forEach( function ( k ) {
			forms[ k ].hidden = k !== which;
		} );
		document.querySelectorAll( '.form-switch a' ).forEach( function ( a ) {
			var on = ( a.getAttribute( 'href' ) + '#' + ( a.getAttribute( 'data-frag' ) || '' ) ).indexOf( '#' + which ) !== -1;
			a.classList.toggle( 'is-active', on );
			a.setAttribute( 'aria-current', on ? 'true' : 'false' );
		} );
	}
	window.leonShowForm = showForm;

	function setupForms() {
		forms.event = document.getElementById( 'event' );
		forms.photo = document.getElementById( 'photo' );
		var other = document.getElementById( 'other' );
		if ( other ) {
			forms.other = other;
		}
		if ( ! forms.event || ! forms.photo || ! document.querySelector( '.form-switch' ) ) {
			return;
		}
		document.querySelectorAll( '.form-switch a' ).forEach( function ( a ) {
			a.addEventListener( 'click', function ( e ) {
				var m = ( a.getAttribute( 'href' ) + '#' + ( a.getAttribute( 'data-frag' ) || '' ) ).match( /#(event|photo|other)\b/ );
				if ( m ) {
					showForm( m[ 1 ] );
				}
				e.preventDefault();
			} );
		} );
		var h = location.hash.slice( 1 );
		showForm( forms[ h ] ? h : 'event' );
	}

	/* ---------- Portfolio filter + View more ---------- */
	var PAGE = 8; // drawings shown before "View more" (two rows of four)
	var DEFAULT_FILTER = 'live'; // the most eye-catching set opens first (Leon's choice)

	function linkTarget( a ) {
		return a.getAttribute( 'href' ) + '#' + ( a.getAttribute( 'data-frag' ) || '' );
	}

	function galleryIds( grid ) {
		return [].map.call( grid.querySelectorAll( '.wp-block-gallery[id]' ), function ( g ) {
			return g.id;
		} );
	}

	// "All" mixes the styles: one drawing from each gallery in turn (the celebrity gallery comes last).
	// The grid reads CSS order, so the drawings stay inside their own galleries in the editor.
	var current = 'all';
	function orderedTiles( grid ) {
		var lists = [].filter.call( grid.querySelectorAll( '.wp-block-gallery[id]' ), function ( g ) {
			return ! g.classList.contains( 'is-filtered-out' );
		} ).map( function ( g ) {
			return { id: g.id, tiles: [].slice.call( g.querySelectorAll( ':scope > figure' ) ) };
		} );
		if ( current !== 'all' ) {
			return lists.reduce( function ( a, l ) {
				return a.concat( l.tiles );
			}, [] );
		}
		var tail = lists.filter( function ( l ) {
			return l.id === 'celebrity';
		} );
		var mix = lists.filter( function ( l ) {
			return l.id !== 'celebrity';
		} );
		var out = [];
		for ( var i = 0; mix.some( function ( l ) { return i < l.tiles.length; } ); i++ ) {
			mix.forEach( function ( l ) {
				if ( l.tiles[ i ] ) {
					out.push( l.tiles[ i ] );
				}
			} );
		}
		tail.forEach( function ( l ) {
			out = out.concat( l.tiles );
		} );
		return out;
	}

	// Leon wants every screenful to be all upright drawings or all wide ones, so the
	// drawings are split into pages of 8: upright pages first, then wide pages.
	// A drawing is "wide" when its image block has the class "is-landscape"
	// (or, once loaded, when the picture itself is wider than tall).
	function isWide( f ) {
		if ( f.classList.contains( 'is-landscape' ) ) {
			return true;
		}
		var im = f.querySelector( 'img' );
		return !! ( im && im.complete && im.naturalWidth > im.naturalHeight * 1.05 );
	}

	var pagesShown = 1;
	function applyMore( grid ) {
		var tiles = orderedTiles( grid );
		var tall = tiles.filter( function ( f ) {
			return ! isWide( f );
		} );
		var wide = tiles.filter( isWide );
		var pages = [];
		[ tall, wide ].forEach( function ( list ) {
			for ( var i = 0; i < list.length; i += PAGE ) {
				pages.push( list.slice( i, i + PAGE ) );
			}
		} );
		var pos = 0;
		pages.forEach( function ( page, p ) {
			page.forEach( function ( f ) {
				f.style.order = pos++;
				f.classList.toggle( 'is-more-hidden', p >= pagesShown );
			} );
		} );
		var more = document.querySelector( '.works-more' );
		if ( more ) {
			more.hidden = pagesShown >= pages.length;
		}
	}

	function filterWorks( which ) {
		var grid = document.querySelector( '.works-grid' );
		if ( ! grid ) {
			return;
		}
		if ( which !== 'all' && galleryIds( grid ).indexOf( which ) === -1 ) {
			which = DEFAULT_FILTER;
		}
		grid.querySelectorAll( '.wp-block-gallery[id]' ).forEach( function ( g ) {
			g.classList.toggle( 'is-filtered-out', which !== 'all' && g.id !== which );
		} );
		document.querySelectorAll( '.work-filter a' ).forEach( function ( a ) {
			var on = linkTarget( a ).split( '#' ).indexOf( which ) > 0;
			a.classList.toggle( 'is-active', on );
			a.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
		} );
		current = which;
		pagesShown = 1;
		applyMore( grid );
	}
	window.leonFilterWorks = filterWorks;

	function setupFilter() {
		var grid = document.querySelector( '.works-grid' );
		if ( ! grid ) {
			return;
		}
		var wrap = document.createElement( 'div' );
		wrap.className = 'works-more wp-block-buttons';
		wrap.innerHTML = '<div class="wp-block-button"><button type="button" class="wp-block-button__link wp-element-button">View more</button></div>';
		grid.parentNode.insertBefore( wrap, grid.nextSibling );
		wrap.querySelector( 'button' ).addEventListener( 'click', function () {
			pagesShown++;
			applyMore( grid );
		} );

		var ids = galleryIds( grid );
		document.querySelectorAll( '.work-filter a' ).forEach( function ( a ) {
			a.setAttribute( 'role', 'button' );
			a.addEventListener( 'click', function ( e ) {
				var m = linkTarget( a ).match( /#([\w-]+)/ );
				if ( m && ( m[ 1 ] === 'all' || ids.indexOf( m[ 1 ] ) !== -1 ) ) {
					e.preventDefault();
					filterWorks( m[ 1 ] );
				}
			} );
		} );
		var bar = document.querySelector( '.work-filter[data-default]' );
		if ( bar ) {
			DEFAULT_FILTER = bar.getAttribute( 'data-default' );
		}
		filterWorks( location.hash.slice( 1 ) || DEFAULT_FILTER );
	}

	var REDUCE = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	var WIDE = window.matchMedia ? window.matchMedia( '(min-width: 1024px)' ) : { matches: true };

	function onVisible( el, ratio, fn ) {
		if ( ! ( 'IntersectionObserver' in window ) ) {
			fn();
			return;
		}
		var io = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( e ) {
				if ( e.isIntersecting ) {
					io.disconnect();
					fn();
				}
			} );
		}, { threshold: ratio } );
		io.observe( el );
	}

	/* ---------- Card stack ---------- */
	function setupStack( stack ) {
		var cards = [].slice.call( stack.querySelectorAll( ':scope > .stack-card' ) );
		var n = cards.length;
		if ( n < 2 ) {
			return;
		}
		var order = cards.map( function ( c, i ) {
			return i;
		} );
		function place() {
			order.forEach( function ( cardIndex, pos ) {
				var c = cards[ cardIndex ];
				var off = cardIndex - ( n - 1 ) / 2;
				c.style.setProperty( '--pos', pos );
				c.style.setProperty( '--off', off );
				c.style.setProperty( '--abs', Math.abs( off ) );
				c.style.zIndex = n - pos;
			} );
		}
		stack.classList.add( 'is-ready' );
		stack.style.setProperty( '--n', n );
		place();
		cards.forEach( function ( c, i ) {
			c.addEventListener( 'click', function () {
				if ( WIDE.matches && stack.classList.contains( 'is-spread' ) ) {
					return;
				}
				if ( WIDE.matches ) {
					stack.classList.add( 'is-spread' );
					return;
				}
				// Phones: the top card slides away and goes to the back of the pile.
				if ( order[ 0 ] !== i || c.classList.contains( 'is-leaving' ) ) {
					return;
				}
				c.classList.add( 'is-leaving' );
				setTimeout( function () {
					order.push( order.shift() );
					place();
					c.classList.remove( 'is-leaving' );
				}, REDUCE ? 0 : 320 );
			} );
		} );
		onVisible( stack, 0.35, function () {
			setTimeout( function () {
				stack.classList.add( 'is-spread' );
			}, REDUCE ? 0 : 250 );
		} );
	}

	/* ---------- Reveal rows ---------- */
	function setupReveal( row, i ) {
		var head = row.querySelector( '.reveal-row__head' );
		var panel = row.querySelector( '.reveal-row__panel' );
		if ( ! head || ! panel ) {
			return;
		}
		panel.id = panel.id || 'reveal-panel-' + i;
		head.setAttribute( 'role', 'button' );
		head.setAttribute( 'tabindex', '0' );
		head.setAttribute( 'aria-controls', panel.id );
		function set( open ) {
			row.classList.toggle( 'is-open', open );
			head.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		}
		// The first row of each list starts open so the section never looks empty.
		set( row.parentNode.querySelector( ':scope > .reveal-row' ) === row );
		row.classList.add( 'is-ready' );
		function toggle() {
			var open = ! row.classList.contains( 'is-open' );
			var list = row.parentNode;
			[].forEach.call( list.querySelectorAll( ':scope > .reveal-row.is-open' ), function ( other ) {
				if ( other !== row ) {
					other.classList.remove( 'is-open' );
					other.querySelector( '.reveal-row__head' ).setAttribute( 'aria-expanded', 'false' );
				}
			} );
			set( open );
		}
		head.addEventListener( 'click', toggle );
		head.addEventListener( 'keydown', function ( e ) {
			if ( e.key === 'Enter' || e.key === ' ' ) {
				e.preventDefault();
				toggle();
			}
		} );
	}

	/* ---------- Doodle drop ---------- */
	function rand( a, b ) {
		return a + Math.random() * ( b - a );
	}

	function setupDrop( pile ) {
		var items = [].slice.call( pile.querySelectorAll( ':scope > .wp-block-image' ) );
		if ( ! items.length ) {
			return;
		}
		pile.classList.add( 'is-ready' );
		var n = items.length;
		items.forEach( function ( fig, i ) {
			var size = rand( 0.8, 1.25 );
			var slot = ( i + rand( 0.1, 0.9 ) ) / n;           // spread across the width
			fig.style.setProperty( '--x', ( 4 + slot * 88 ).toFixed( 1 ) + '%' );
			fig.style.setProperty( '--s', size.toFixed( 2 ) );
			fig.style.setProperty( '--rest', Math.round( rand( 0, 28 ) ) + 'px' );
			fig.style.setProperty( '--r', Math.round( rand( -35, 35 ) ) + 'deg' );
			fig.style.zIndex = Math.round( rand( 1, 9 ) );
		} );

		/* A falling doodle is simulated like a light ball: gravity, a few softer and
		   softer bounces, while its spin and sideways drift ease out. The path is
		   sampled at 60 frames a second and played back linearly, so it stays smooth. */
		var G = 2600;      // px/s^2
		var STEP = 1 / 60;
		function easeOut( p ) {
			return 1 - Math.pow( 1 - p, 3 );
		}
		function path( y0, v0, bounce ) {
			var ys = [];
			var y = y0, v = v0;
			for ( var t = 0; t < 3.2; t += STEP ) {
				v += G * STEP;
				y += v * STEP;
				if ( y >= 0 ) {
					y = 0;
					if ( Math.abs( v ) < 170 ) {
						ys.push( 0 );
						break;
					}
					v = -v * bounce;
				}
				ys.push( y );
			}
			return ys;
		}
		function play( fig, ys, rFrom, rTo, dx, opts ) {
			var n = ys.length;
			var frames = ys.map( function ( y, i ) {
				var p = easeOut( i / ( n - 1 ) );
				var r = rTo + ( rFrom - rTo ) * ( 1 - p );
				var x = dx * ( 1 - p );
				return { transform: 'translate(' + x.toFixed( 1 ) + 'px,' + y.toFixed( 1 ) + 'px) rotate(' + r.toFixed( 1 ) + 'deg)' };
			} );
			return fig.animate( frames, Object.assign( { duration: n * STEP * 1000, easing: 'linear' }, opts || {} ) );
		}
		function angle( fig ) {
			return parseFloat( getComputedStyle( fig ).getPropertyValue( '--r' ) ) || 0;
		}

		function drop() {
			pile.classList.add( 'has-dropped' );
			if ( REDUCE || ! items[ 0 ].animate ) {
				return;
			}
			var h = pile.getBoundingClientRect().height + 60; // start just above the pile (the strip clips them)
			items.forEach( function ( fig ) {
				var r = angle( fig );
				var ys = path( -h - rand( 0, 90 ), 0, rand( 0.34, 0.46 ) );
				play( fig, ys, r + rand( -160, 160 ), r, rand( -40, 40 ), { delay: rand( 0, 900 ), fill: 'backwards' } );
			} );
		}

		/* Tap a doodle: it hops, flips once and lands at a new angle. */
		items.forEach( function ( fig ) {
			fig.addEventListener( 'click', function () {
				if ( REDUCE || ! fig.animate ) {
					return;
				}
				var r = angle( fig );
				var nr = Math.round( rand( -35, 35 ) );
				fig.style.setProperty( '--r', nr + 'deg' );
				var ys = path( 0, -rand( 620, 820 ), 0.32 );
				play( fig, ys, r, nr + ( Math.random() < 0.5 ? -360 : 360 ), 0 );
			} );
		} );

		onVisible( pile, 0.3, drop );
	}

	/* ---------- Rotating gallery ----------
	   All three spots change at the same moment: the next three drawings are loaded
	   first, then the cards flash and the new drawings fade in together. */
	function setupRotator( gal ) {
		var figs = [].slice.call( gal.querySelectorAll( ':scope > figure.wp-block-image' ) );
		var pool = figs.map( function ( f ) {
			var im = f.querySelector( 'img' );
			return im ? { src: im.currentSrc || im.src, alt: im.alt } : null;
		} ).filter( Boolean );
		var SLOTS = 3;
		if ( REDUCE || pool.length <= SLOTS ) {
			return;
		}
		var slots = figs.slice( 0, SLOTS );
		var first = 0; // pool index of the drawing in the first spot
		var busy = false;
		var running = false;
		var timer = null;
		var pending = null;

		function load( i ) {
			return new Promise( function ( done ) {
				var im = new Image();
				im.onload = im.onerror = function () {
					( im.decode ? im.decode().catch( function () {} ) : Promise.resolve() ).then( done );
				};
				im.src = pool[ i ].src;
			} );
		}
		function prepare() {
			var set = [];
			for ( var k = 0; k < SLOTS; k++ ) {
				set.push( ( first + SLOTS + k ) % pool.length );
			}
			pending = { set: set, ready: Promise.all( set.map( load ) ) };
		}
		prepare();

		function swap() {
			if ( busy ) {
				return;
			}
			busy = true;
			var p = pending;
			p.ready.then( function () {
				var olds = [];
				var news = [];
				slots.forEach( function ( fig, k ) {
					var old = fig.querySelector( 'img:not(.rot-out)' );
					var img = document.createElement( 'img' );
					img.src = pool[ p.set[ k ] ].src;
					img.alt = pool[ p.set[ k ] ].alt;
					img.className = 'rot-layer rot-enter';
					fig.appendChild( img );
					olds.push( old );
					news.push( img );
				} );
				gal.classList.remove( 'is-flashing' );
				void gal.offsetWidth; // restart the flash animation
				gal.classList.add( 'is-flashing' );
				requestAnimationFrame( function () {
					requestAnimationFrame( function () {
						news.forEach( function ( im ) {
							im.classList.remove( 'rot-enter' );
						} );
						olds.forEach( function ( im ) {
							if ( im ) {
								im.classList.add( 'rot-out' );
							}
						} );
					} );
				} );
				setTimeout( function () {
					olds.forEach( function ( im ) {
						if ( im && im.parentNode ) {
							im.parentNode.removeChild( im );
						}
					} );
					news.forEach( function ( im ) {
						im.classList.remove( 'rot-layer' );
					} );
					gal.classList.remove( 'is-flashing' );
					first = p.set[ 0 ];
					busy = false;
					prepare();
				}, 800 );
			} );
		}
		function start() {
			if ( ! running ) {
				running = true;
				timer = setInterval( swap, 4200 );
			}
		}
		function stop() {
			running = false;
			clearInterval( timer );
		}
		gal.classList.add( 'is-rotating' );
		if ( 'IntersectionObserver' in window ) {
			new IntersectionObserver( function ( entries ) {
				entries.forEach( function ( e ) {
					if ( e.isIntersecting && ! document.hidden ) {
						start();
					} else {
						stop();
					}
				} );
			}, { threshold: 0.2 } ).observe( gal );
		} else {
			start();
		}
		document.addEventListener( 'visibilitychange', function () {
			if ( document.hidden ) {
				stop();
			}
		} );
	}

	/* ---------- Header: hides while scrolling down, comes back when scrolling up ---------- */
	function setupHeader() {
		var head = document.querySelector( '.wp-site-blocks > header' );
		if ( ! head ) {
			return;
		}
		var last = window.scrollY;
		var busy = false;
		function update() {
			busy = false;
			var y = window.scrollY;
			var menuOpen = document.querySelector( '.wp-block-navigation__responsive-container.is-menu-open' );
			if ( menuOpen || y < 120 || head.contains( document.activeElement ) ) {
				head.classList.remove( 'is-tucked' );
			} else if ( y > last + 8 ) {
				head.classList.add( 'is-tucked' );
			} else if ( y < last - 8 ) {
				head.classList.remove( 'is-tucked' );
			}
			last = y;
		}
		window.addEventListener( 'scroll', function () {
			if ( ! busy ) {
				busy = true;
				requestAnimationFrame( update );
			}
		}, { passive: true } );
		head.addEventListener( 'focusin', function () {
			head.classList.remove( 'is-tucked' );
		} );
	}

	/* ---------- Header height, for the hero that fills the window below it ---------- */
	function setupHeaderHeight() {
		var head = document.querySelector( '.wp-site-blocks > header' );
		if ( ! head ) {
			return;
		}
		function set() {
			document.documentElement.style.setProperty( '--hdr', head.offsetHeight + 'px' );
		}
		set();
		window.addEventListener( 'resize', set );
		window.addEventListener( 'load', set );
	}

	/* ---------- Crossfade gallery ----------
	   A gallery with the "Crossfade" style shows one picture at a time, each fading
	   into the next. Paused while off screen. */
	function setupCrossfade( gal ) {
		var figs = [].slice.call( gal.querySelectorAll( ':scope > figure.wp-block-image' ) );
		if ( REDUCE || figs.length < 2 ) {
			return;
		}
		var every = gal.classList.contains( 'hero-fade' ) ? 6000 : 4200;
		var i = 0;
		var timer = null;
		figs.forEach( function ( f ) {
			var im = f.querySelector( 'img' );
			if ( im ) {
				im.loading = 'eager';
			}
		} );
		figs[ 0 ].classList.add( 'is-current' );
		gal.classList.add( 'is-ready' );
		function next() {
			var out = figs[ i ];
			i = ( i + 1 ) % figs.length;
			var into = figs[ i ];
			out.classList.remove( 'is-current' );
			into.classList.add( 'is-current' );
		}
		function start() {
			if ( ! timer ) {
				timer = setInterval( next, every );
			}
		}
		function stop() {
			clearInterval( timer );
			timer = null;
		}
		if ( 'IntersectionObserver' in window ) {
			new IntersectionObserver( function ( entries ) {
				entries.forEach( function ( e ) {
					if ( e.isIntersecting && ! document.hidden ) {
						start();
					} else {
						stop();
					}
				} );
			}, { threshold: 0.15 } ).observe( gal );
		} else {
			start();
		}
		document.addEventListener( 'visibilitychange', function () {
			if ( document.hidden ) {
				stop();
			}
		} );
	}

	/* ---------- Slide gallery: a filmstrip that never stops ----------
	   A gallery with the "Slide" style puts its pictures side by side, each as wide
	   as the gallery, and the strip moves slowly to the left all the time. A copy of
	   the pictures follows the originals, so the strip loops without a jump.
	   Paused while off screen; still (first picture only) with reduced motion. */
	function setupSlide( gal ) {
		var figs = [].slice.call( gal.querySelectorAll( ':scope > figure.wp-block-image' ) );
		if ( REDUCE || figs.length < 2 ) {
			return;
		}
		var track = document.createElement( 'div' );
		track.className = 'slide-track';
		figs.forEach( function ( f ) {
			var im = f.querySelector( 'img' );
			if ( im ) {
				im.loading = 'eager';
			}
			track.appendChild( f );
		} );
		figs.forEach( function ( f ) {
			var c = f.cloneNode( true );
			c.setAttribute( 'aria-hidden', 'true' );
			c.inert = true;
			c.querySelectorAll( '[id]' ).forEach( function ( el ) {
				el.removeAttribute( 'id' );
			} );
			track.appendChild( c );
		} );
		gal.appendChild( track );
		gal.classList.add( 'is-marquee' );

		function size() {
			var w = gal.clientWidth || window.innerWidth;
			// About one picture every 22 seconds on a computer; never slower than 30px a second.
			var speed = Math.max( 30, w / 22 );
			gal.style.setProperty( '--slide-w', w + 'px' );
			gal.style.setProperty( '--slide-dur', ( w * figs.length / speed ).toFixed( 1 ) + 's' );
		}
		size();
		var t;
		window.addEventListener( 'resize', function () {
			clearTimeout( t );
			t = setTimeout( size, 150 );
		} );

		var visible = true;
		function update() {
			gal.classList.toggle( 'is-paused', ! visible || document.hidden );
		}
		if ( 'IntersectionObserver' in window ) {
			new IntersectionObserver( function ( entries ) {
				entries.forEach( function ( e ) {
					visible = e.isIntersecting;
					update();
				} );
			}, { threshold: 0 } ).observe( gal );
		}
		document.addEventListener( 'visibilitychange', update );
	}

	/* ---------- Book Leon menu links switch the form on the Book Leon page itself ---------- */
	function setupHashForms() {
		window.addEventListener( 'hashchange', function () {
			var m = location.hash.match( /^#(event|photo|other)$/ );
			if ( ! m || ! forms[ m[ 1 ] ] ) {
				return;
			}
			showForm( m[ 1 ] );
			var close = document.querySelector( '.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation__responsive-container-close' );
			if ( close ) {
				close.click();
			}
			var top = document.querySelector( '.contact-page' );
			if ( top ) {
				top.scrollIntoView( { behavior: 'smooth', block: 'start' } );
			}
		} );
	}

	/* ---------- Menu: mark the page you are on ----------
	   The menu links are typed-in links, so WordPress cannot tell which one is the
	   current page. Compare each link with the address instead. */
	function cleanPath( url ) {
		var a = document.createElement( 'a' );
		a.href = url;
		return a.pathname.replace( /\/+$/, '' ) || '/';
	}

	function setupCurrentMenu() {
		var here = cleanPath( location.href );
		document.querySelectorAll( '.wp-block-navigation a.wp-block-navigation-item__content' ).forEach( function ( a ) {
			var href = a.getAttribute( 'href' ) || '';
			if ( ! href || href.charAt( 0 ) === '#' || a.closest( '.wp-block-navigation__submenu-container' ) ) {
				return;
			}
			if ( a.hostname && a.hostname !== location.hostname ) {
				return;
			}
			var target = cleanPath( a.href );
			// "/" only counts on the real home page (preview links also use "/?page_id=").
			if ( target === '/' ? document.body.classList.contains( 'home' ) : target === here ) {
				var li = a.closest( '.wp-block-navigation-item' );
				if ( li ) {
					li.classList.add( 'is-current' );
				}
				a.setAttribute( 'aria-current', 'page' );
			}
		} );
	}

	/* ---------- Face letters: lettering, not artwork ----------
	   The hero letters are a Gallery block, so both the WordPress zoom and the
	   WordPress.com (Jetpack) carousel would open when a letter is clicked.
	   Catch the click on the gallery first so neither of them gets it.
	   Hover still works, so the letters keep their little jump. */
	function setupFaceLetters( gal ) {
		gal.removeAttribute( 'data-carousel-extra' );
		gal.addEventListener( 'click', function ( e ) {
			e.preventDefault();
			e.stopPropagation();
		}, true );
	}

	function init() {
		document.querySelectorAll( '.guest-calc' ).forEach( setupCalc );
		setupForms();
		setupFilter();
		document.querySelectorAll( '.card-stack' ).forEach( setupStack );
		document.querySelectorAll( '.reveal-row' ).forEach( setupReveal );
		document.querySelectorAll( '.doodle-drop__pile' ).forEach( setupDrop );
		document.querySelectorAll( '.wp-block-gallery.is-rotator' ).forEach( setupRotator );
		setupHeader();
		setupHeaderHeight();
		document.querySelectorAll( '.wp-block-gallery.is-style-crossfade' ).forEach( setupCrossfade );
		document.querySelectorAll( '.wp-block-gallery.is-style-slide' ).forEach( setupSlide );
		setupHashForms();
		setupCurrentMenu();
		document.querySelectorAll( '.wp-block-gallery.is-style-face-letters' ).forEach( setupFaceLetters );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
