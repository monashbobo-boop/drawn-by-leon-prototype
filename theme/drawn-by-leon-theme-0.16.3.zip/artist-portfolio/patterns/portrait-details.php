<?php
/**
 * Title: Custom portraits: service details
 * Slug: artist-portfolio/portrait-details
 * Categories: artist-sections, services
 * Description: Service details for portraits from photos as a stack of photo cards beside the details. Each card is a group: change its photo, title and words, or duplicate a card to add one.
 * Keywords: details, cards, photos, turnaround, delivery, postage
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1100px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60","top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"32%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:32%"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Service details</h2>
<!-- /wp:heading -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full","className":"details-mascot"} -->
<figure class="wp-block-image size-full details-mascot"><img src="<?php echo artist_portfolio_image( 'brand/mascot-sketching.webp' ); ?>" alt="Leon's cartoon self sitting in a director's chair, sketching on a clipboard"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"68%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:68%"><!-- wp:group {"metadata":{"name":"Service details cards"},"className":"details-cards details-deck","layout":{"type":"default"}} -->
<div class="wp-block-group details-cards details-deck"><!-- wp:group {"metadata":{"name":"Detail: Artwork format"},"className":"detail-card","layout":{"type":"default"}} -->
<div class="wp-block-group detail-card"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"detail-card__photo"} -->
<figure class="wp-block-image size-large detail-card__photo"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-01.webp' ); ?>" alt="Colour caricature of a bride and groom, drawn from a photo"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"detail-card__label"} -->
<h3 class="wp-block-heading detail-card__label">Artwork format</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"detail-card__text"} -->
<p class="detail-card__text">A3 original on paper or a digital file</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Detail: Style"},"className":"detail-card","layout":{"type":"default"}} -->
<div class="wp-block-group detail-card"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"detail-card__photo"} -->
<figure class="wp-block-image size-large detail-card__photo"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-12.webp' ); ?>" alt="Colour caricature of a man hugging his dog, drawn from a photo"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"detail-card__label"} -->
<h3 class="wp-block-heading detail-card__label">Style</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"detail-card__text"} -->
<p class="detail-card__text">Black and white or colour</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Detail: People"},"className":"detail-card","layout":{"type":"default"}} -->
<div class="wp-block-group detail-card"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"detail-card__photo"} -->
<figure class="wp-block-image size-large detail-card__photo"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-13.webp' ); ?>" alt="Colour caricature of three friends raising their drinks"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"detail-card__label"} -->
<h3 class="wp-block-heading detail-card__label">People</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"detail-card__text"} -->
<p class="detail-card__text">Individuals, couples, friends or families</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Detail: Completion time"},"className":"detail-card","layout":{"type":"default"}} -->
<div class="wp-block-group detail-card"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"detail-card__photo"} -->
<figure class="wp-block-image size-large detail-card__photo"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-04.webp' ); ?>" alt="Colour caricature for a 40th birthday"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"detail-card__label"} -->
<h3 class="wp-block-heading detail-card__label">Completion time</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"detail-card__text"} -->
<p class="detail-card__text">Usually within five business days once photos, requirements and payment are confirmed</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Detail: Personalisation"},"className":"detail-card","layout":{"type":"default"}} -->
<div class="wp-block-group detail-card"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"detail-card__photo"} -->
<figure class="wp-block-image size-large detail-card__photo"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-07.webp' ); ?>" alt="Colour caricature of a man riding a motorbike down a desert road"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"detail-card__label"} -->
<h3 class="wp-block-heading detail-card__label">Personalisation</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"detail-card__text"} -->
<p class="detail-card__text">Clothing requests, or an added body, background or theme. Any additional costs are confirmed in advance.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Detail: Delivery"},"className":"detail-card","layout":{"type":"default"}} -->
<div class="wp-block-group detail-card"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"detail-card__photo"} -->
<figure class="wp-block-image size-large detail-card__photo"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-05.webp' ); ?>" alt="Colour caricature of a couple with flowers"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"detail-card__label"} -->
<h3 class="wp-block-heading detail-card__label">Delivery</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"detail-card__text"} -->
<p class="detail-card__text">Originals can be posted. Digital files are sent by email.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Detail: Postage"},"className":"detail-card","layout":{"type":"default"}} -->
<div class="wp-block-group detail-card"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"detail-card__photo"} -->
<figure class="wp-block-image size-large detail-card__photo"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-10.webp' ); ?>" alt="Colour caricature of a little girl with pigtails"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"detail-card__label"} -->
<h3 class="wp-block-heading detail-card__label">Postage</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"detail-card__text"} -->
<p class="detail-card__text">Confirmed in your quote based on your address and delivery method</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
