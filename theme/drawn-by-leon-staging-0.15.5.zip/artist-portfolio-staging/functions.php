<?php
/**
 * Artist Portfolio theme setup.
 *
 * Everything visual lives in theme.json, assets/css/theme.css and patterns/.
 * This file only loads styles, registers block styles and pattern categories.
 *
 * @package ArtistPortfolio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ARTIST_PORTFOLIO_VERSION', wp_get_theme()->get( 'Version' ) );

/**
 * Theme supports and editor styles.
 */
add_action(
	'after_setup_theme',
	function () {
		add_theme_support( 'editor-styles' );
		add_editor_style( 'assets/css/theme.css' );
	}
);

/**
 * Front-end stylesheet. Versioned by file time locally, by theme version otherwise.
 */
add_action(
	'wp_enqueue_scripts',
	function () {
		$path = get_theme_file_path( 'assets/css/theme.css' );
		wp_enqueue_style(
			'artist-portfolio',
			get_theme_file_uri( 'assets/css/theme.css' ),
			array(),
			file_exists( $path ) ? (string) filemtime( $path ) : ARTIST_PORTFOLIO_VERSION
		);

		$js = get_theme_file_path( 'assets/js/draw-reveal.js' );
		wp_enqueue_script(
			'artist-portfolio-draw-reveal',
			get_theme_file_uri( 'assets/js/draw-reveal.js' ),
			array(),
			file_exists( $js ) ? (string) filemtime( $js ) : ARTIST_PORTFOLIO_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);

		$site_js = get_theme_file_path( 'assets/js/site.js' );
		wp_enqueue_script(
			'artist-portfolio-site',
			get_theme_file_uri( 'assets/js/site.js' ),
			array(),
			file_exists( $site_js ) ? (string) filemtime( $site_js ) : ARTIST_PORTFOLIO_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}
);

/**
 * Service details as cards (assets/js/details-cards.js). Loaded only on pages whose
 * table has the class "details-deck" or "details-pile"; GSAP + Flip (bundled in
 * assets/js/vendor, free under GreenSock's standard license) only for "details-pile".
 */
add_action(
	'wp_enqueue_scripts',
	function () {
		$post = get_queried_object();
		if ( ! ( $post instanceof WP_Post ) ) {
			return;
		}
		$deck = false !== strpos( $post->post_content, 'details-deck' );
		$pile = false !== strpos( $post->post_content, 'details-pile' );
		if ( ! $deck && ! $pile ) {
			return;
		}
		$deps = array();
		if ( $pile ) {
			wp_enqueue_script( 'artist-portfolio-gsap', get_theme_file_uri( 'assets/js/vendor/gsap.min.js' ), array(), '3.15.1', array( 'in_footer' => true, 'strategy' => 'defer' ) );
			wp_enqueue_script( 'artist-portfolio-gsap-flip', get_theme_file_uri( 'assets/js/vendor/Flip.min.js' ), array( 'artist-portfolio-gsap' ), '3.15.1', array( 'in_footer' => true, 'strategy' => 'defer' ) );
			$deps = array( 'artist-portfolio-gsap', 'artist-portfolio-gsap-flip' );
		}
		$js = get_theme_file_path( 'assets/js/details-cards.js' );
		wp_enqueue_script(
			'artist-portfolio-details-cards',
			get_theme_file_uri( 'assets/js/details-cards.js' ),
			$deps,
			file_exists( $js ) ? (string) filemtime( $js ) : ARTIST_PORTFOLIO_VERSION,
			array( 'in_footer' => true, 'strategy' => 'defer' )
		);
	}
);

/**
 * Editor: "Portfolio filter" panel in the page sidebar (assets/js/editor-portfolio.js).
 */
add_action(
	'enqueue_block_editor_assets',
	function () {
		$js = get_theme_file_path( 'assets/js/editor-portfolio.js' );
		wp_enqueue_script(
			'artist-portfolio-editor-portfolio',
			get_theme_file_uri( 'assets/js/editor-portfolio.js' ),
			array( 'wp-plugins', 'wp-element', 'wp-data', 'wp-components', 'wp-editor', 'wp-block-editor' ),
			file_exists( $js ) ? (string) filemtime( $js ) : ARTIST_PORTFOLIO_VERSION,
			true
		);
	}
);

/**
 * Hand-drawn block styles the artist can switch on in the editor sidebar.
 */
add_action(
	'init',
	function () {
		register_block_style(
			'core/heading',
			array(
				'name'  => 'doodle-underline',
				'label' => __( 'Doodle underline', 'artist-portfolio' ),
			)
		);
		register_block_style(
			'core/image',
			array(
				'name'  => 'sketch-frame',
				'label' => __( 'Sketch frame', 'artist-portfolio' ),
			)
		);
		register_block_style(
			'core/image',
			array(
				'name'  => 'taped',
				'label' => __( 'Taped photo', 'artist-portfolio' ),
			)
		);
		register_block_style(
			'core/group',
			array(
				'name'  => 'card',
				'label' => __( 'Sketch card', 'artist-portfolio' ),
			)
		);
		register_block_style(
			'core/group',
			array(
				'name'  => 'panel',
				'label' => __( 'Navy panel', 'artist-portfolio' ),
			)
		);
		register_block_style(
			'core/group',
			array(
				'name'  => 'wave-top',
				'label' => __( 'Wavy top edge', 'artist-portfolio' ),
			)
		);
		register_block_style(
			'core/image',
			array(
				'name'  => 'sticker',
				'label' => __( 'Spinning sticker', 'artist-portfolio' ),
			)
		);
		register_block_style(
			'core/image',
			array(
				'name'  => 'draw-reveal',
				'label' => __( 'Your face here (drawing)', 'artist-portfolio' ),
			)
		);
		register_block_style(
			'core/gallery',
			array(
				'name'  => 'masonry',
				'label' => __( 'Small tiles', 'artist-portfolio' ),
			)
		);
		register_block_style(
			'core/gallery',
			array(
				'name'  => 'scatter',
				'label' => __( 'Scattered', 'artist-portfolio' ),
			)
		);
		// Home hero: one picture per letter of CARICATURES; a few letters come alive now and then.
		register_block_style(
			'core/gallery',
			array(
				'name'  => 'face-letters',
				'label' => __( 'Face letters', 'artist-portfolio' ),
			)
		);
		// One picture at a time, each fading into the next (home hero photos).
		register_block_style(
			'core/gallery',
			array(
				'name'  => 'crossfade',
				'label' => __( 'Crossfade', 'artist-portfolio' ),
			)
		);
		// Five framed drawings scattered on top of each other (Two ways: drawn from photos).
		register_block_style(
			'core/gallery',
			array(
				'name'  => 'collage',
				'label' => __( 'Collage (5 pictures)', 'artist-portfolio' ),
			)
		);
		// Numbered steps in yellow circles (Live caricatures: how booking works).
		register_block_style(
			'core/list',
			array(
				'name'  => 'steps',
				'label' => __( 'Steps', 'artist-portfolio' ),
			)
		);
		// Yellow tick for each item (Custom portraits: what to send me).
		register_block_style(
			'core/list',
			array(
				'name'  => 'ticks',
				'label' => __( 'Ticks', 'artist-portfolio' ),
			)
		);

		register_block_pattern_category(
			'artist-sections',
			array( 'label' => __( 'Artist: sections', 'artist-portfolio' ) )
		);
		register_block_pattern_category(
			'artist-pages',
			array( 'label' => __( 'Artist: full pages', 'artist-portfolio' ) )
		);
	}
);

/**
 * URL of a bundled placeholder image, for use inside patterns.
 *
 * @param string $file File name inside assets/images/placeholders.
 * @return string Escaped URL.
 */
function artist_portfolio_placeholder( $file ) {
	return esc_url( get_theme_file_uri( 'assets/images/placeholders/' . $file ) );
}

/**
 * URL of a bundled doodle (icons, stickers), for use inside patterns.
 *
 * @param string $file File name inside assets/images/doodles.
 * @return string Escaped URL.
 */
function artist_portfolio_doodle( $file ) {
	return esc_url( get_theme_file_uri( 'assets/images/doodles/' . $file ) );
}

/**
 * URL of a bundled sample artwork or brand image, for use inside patterns.
 * Leon replaces these in the editor with his own uploads.
 *
 * @param string $file Path inside assets/images (e.g. 'samples/couple.webp').
 * @return string Escaped URL.
 */
function artist_portfolio_image( $file ) {
	return esc_url( get_theme_file_uri( 'assets/images/' . $file ) );
}

$artist_portfolio_inc = get_theme_file_path( 'inc/portfolio.php' );
if ( file_exists( $artist_portfolio_inc ) ) {
	require_once $artist_portfolio_inc;
}

/**
 * "{year}" in any paragraph (the footer copyright line) shows the current year,
 * so the footer never needs a yearly edit.
 */
add_filter(
	'render_block_core/paragraph',
	function ( $content ) {
		if ( false === strpos( $content, '{year}' ) ) {
			return $content;
		}
		return str_replace( '{year}', esc_html( wp_date( 'Y' ) ), $content );
	}
);

/**
 * Business details for search engines (schema.org LocalBusiness), on the home page only.
 * Name, link and description come from Settings > General; contact details are below.
 */
add_action(
	'wp_head',
	function () {
		if ( ! is_front_page() ) {
			return;
		}
		$data = array(
			'@context'    => 'https://schema.org',
			'@type'       => 'LocalBusiness',
			'name'        => get_bloginfo( 'name' ),
			'description' => 'Hand-drawn caricatures, live at weddings, parties and events, or drawn from your photos.',
			'url'         => home_url( '/' ),
			'telephone'   => '+61466532313',
			'email'       => 'leon.caricature@gmail.com',
			'areaServed'  => array(
				'@type' => 'City',
				'name'  => 'Melbourne',
			),
			'address'     => array(
				'@type'           => 'PostalAddress',
				'addressLocality' => 'Melbourne',
				'addressRegion'   => 'VIC',
				'addressCountry'  => 'AU',
			),
			'sameAs'      => array(
				'https://www.instagram.com/leon.caricature',
				'https://www.facebook.com/leon.caricature',
			),
			'knowsAbout'  => array( 'Caricature', 'Live caricature drawing', 'Wedding entertainment', 'Party entertainment', 'Custom portraits' ),
		);
		$logo_id = get_theme_mod( 'custom_logo' );
		if ( $logo_id ) {
			$data['logo'] = wp_get_attachment_image_url( $logo_id, 'full' );
		}
		echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES ) . "</script>\n";
	}
);

