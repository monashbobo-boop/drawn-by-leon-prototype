<?php
/**
 * Title: Live events: service details
 * Slug: artist-portfolio/event-details
 * Categories: artist-sections, services
 * Description: Service details as a pile of photo cards. Each card is a group: change its photo, title and words, or duplicate a card to add one. On the page the pile opens into one big photo with its details.
 * Keywords: details, cards, photos, included, booking, area
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1100px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60","top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"32%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:32%"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Service details</h2>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"68%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:68%"><!-- wp:group {"metadata":{"name":"Service details cards"},"className":"details-cards details-pile","layout":{"type":"default"}} -->
<div class="wp-block-group details-cards details-pile"><!-- wp:group {"metadata":{"name":"Detail: Drawing format"},"className":"detail-card","layout":{"type":"default"}} -->
<div class="wp-block-group detail-card"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"detail-card__photo"} -->
<figure class="wp-block-image size-large detail-card__photo"><img src="<?php echo artist_portfolio_image( 'photos/guests-show-1.webp' ); ?>" alt="A couple holding up their black and white caricature at a show"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"detail-card__label"} -->
<h3 class="wp-block-heading detail-card__label">Drawing format</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"detail-card__text"} -->
<p class="detail-card__text">Hand-drawn on A4 paper, in black and white or colour</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Detail: Drawing rate"},"className":"detail-card","layout":{"type":"default"}} -->
<div class="wp-block-group detail-card"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"detail-card__photo"} -->
<figure class="wp-block-image size-large detail-card__photo"><img src="<?php echo artist_portfolio_image( 'photos/event-leon-booth.webp' ); ?>" alt="Leon drawing at his booth with finished caricatures hanging behind him"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"detail-card__label"} -->
<h3 class="wp-block-heading detail-card__label">Drawing rate</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"detail-card__text"} -->
<p class="detail-card__text">Around 12-15 people per hour in black and white, or 8-10 in colour</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Detail: Group portraits"},"className":"detail-card","layout":{"type":"default"}} -->
<div class="wp-block-group detail-card"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"detail-card__photo"} -->
<figure class="wp-block-image size-large detail-card__photo"><img src="<?php echo artist_portfolio_image( 'photos/event-wedding-guests.webp' ); ?>" alt="Three wedding guests holding up a caricature of all three of them"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"detail-card__label"} -->
<h3 class="wp-block-heading detail-card__label">Group portraits</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"detail-card__text"} -->
<p class="detail-card__text">One or two people per A4 sheet recommended. Larger groups can be discussed in advance.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Detail: Minimum booking"},"className":"detail-card","layout":{"type":"default"}} -->
<div class="wp-block-group detail-card"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"detail-card__photo"} -->
<figure class="wp-block-image size-large detail-card__photo"><img src="<?php echo artist_portfolio_image( 'photos/leon-drawing-wedding.webp' ); ?>" alt="Leon drawing guests at a wedding reception"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"detail-card__label"} -->
<h3 class="wp-block-heading detail-card__label">Minimum booking</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"detail-card__text"} -->
<p class="detail-card__text">Two hours</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Detail: Included"},"className":"detail-card","layout":{"type":"default"}} -->
<div class="wp-block-group detail-card"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"detail-card__photo"} -->
<figure class="wp-block-image size-large detail-card__photo"><img src="<?php echo artist_portfolio_image( 'photos/santa-couple.webp' ); ?>" alt="Mr and Mrs Claus holding up the caricature Leon drew of them"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"detail-card__label"} -->
<h3 class="wp-block-heading detail-card__label">Included</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"detail-card__text"} -->
<p class="detail-card__text">Paper and drawing materials. Guests keep their original artwork.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Detail: Service area"},"className":"detail-card","layout":{"type":"default"}} -->
<div class="wp-block-group detail-card"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"detail-card__photo"} -->
<figure class="wp-block-image size-large detail-card__photo"><img src="<?php echo artist_portfolio_image( 'photos/guests-festival-2.webp' ); ?>" alt="A guest at an outdoor festival holding up his caricature"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"detail-card__label"} -->
<h3 class="wp-block-heading detail-card__label">Service area</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"detail-card__text"} -->
<p class="detail-card__text">Melbourne and surrounding areas. Other locations by enquiry.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
