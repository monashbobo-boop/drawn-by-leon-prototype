<?php
/**
 * Title: Kind words: one more review
 * Slug: artist-portfolio/review-card
 * Categories: artist-sections, testimonials
 * Description: One review card for the Kind words pile. Insert it inside the Kind words cards group (or duplicate an existing card), then change the icon, the quote, the name and the card colour.
 * Keywords: review, testimonial, quote, kind words, card
 * Inserter: true
 */
?>
<!-- wp:group {"metadata":{"name":"Review: new"},"className":"stack-card","backgroundColor":"yellow","textColor":"navy","layout":{"type":"default"}} -->
<div class="wp-block-group stack-card has-navy-color has-yellow-background-color has-text-color has-background"><!-- wp:image {"lightbox":{"enabled":false},"width":"52px","sizeSlug":"full","className":"stack-card__icon"} -->
<figure class="wp-block-image size-full is-resized stack-card__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-quote.webp' ); ?>" alt="" style="width:52px"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"stack-card__quote","fontSize":"large"} -->
<p class="stack-card__quote has-large-font-size">“Write the customer's words here.”</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"stack-card__name","fontSize":"small"} -->
<p class="stack-card__name has-small-font-size">First name · Occasion</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
