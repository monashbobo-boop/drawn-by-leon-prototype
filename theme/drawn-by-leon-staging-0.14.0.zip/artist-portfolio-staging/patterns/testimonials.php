<?php
/**
 * Title: Testimonials: Kind words pile
 * Slug: artist-portfolio/testimonials
 * Categories: artist-sections, testimonials
 * Description: Reviews as a pile of drawings. Tap the pile and it opens into one big drawing with its review; the others line up beside it. Each review is a group: change its picture, quote, name and colour, or duplicate a group to add a review.
 * Keywords: reviews, testimonials, quotes, clients, cards, kind words
 */
?>
<!-- wp:group {"align":"full","className":"testimonials","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull testimonials" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:paragraph {"align":"center","className":"hand-note is-small","textColor":"navy-soft"} -->
<p class="has-text-align-center hand-note is-small has-navy-soft-color has-text-color">what people say</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-text-align-center has-xx-large-font-size">Kind words</h2>
<!-- /wp:heading -->

<!-- wp:group {"align":"wide","className":"kind-words","style":{"spacing":{"margin":{"top":"var:preset|spacing|50"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide kind-words" style="margin-top:var(--wp--preset--spacing--50)"><!-- wp:group {"className":"kind-card","backgroundColor":"yellow","textColor":"navy","layout":{"type":"default"}} -->
<div class="wp-block-group kind-card has-navy-color has-yellow-background-color has-text-color has-background"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"kind-card__art"} -->
<figure class="wp-block-image size-large kind-card__art"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-01.webp' ); ?>" alt="Colour wedding caricature of a bride and groom"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"kind-card__quote"} -->
<p class="kind-card__quote">“We can't thank you enough for all your efforts last night! All the guests absolutely loved them and it's something we will all cherish.”</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"kind-card__name"} -->
<p class="kind-card__name">Bita · Wedding</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"kind-card","backgroundColor":"navy","textColor":"white","layout":{"type":"default"}} -->
<div class="wp-block-group kind-card has-white-color has-navy-background-color has-text-color has-background"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"kind-card__art"} -->
<figure class="wp-block-image size-large kind-card__art"><img src="<?php echo artist_portfolio_image( 'works/live-colour/live-colour-34.webp' ); ?>" alt="Colour caricature of a mother and her two daughters, drawn live"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"kind-card__quote"} -->
<p class="kind-card__quote">“We appreciate your dedication and amazing work! Everyone loved their picture. We are so happy to have met you.”</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"kind-card__name"} -->
<p class="kind-card__name">Trang &amp; Eva · Party</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"kind-card","backgroundColor":"white","textColor":"navy","layout":{"type":"default"}} -->
<div class="wp-block-group kind-card has-navy-color has-white-background-color has-text-color has-background"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"kind-card__art"} -->
<figure class="wp-block-image size-large kind-card__art"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-12.webp' ); ?>" alt="Colour portrait of a man hugging his dog, drawn from a photo"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"kind-card__quote"} -->
<p class="kind-card__quote">“Thank you so much for the drawing of our dad and animals. It's absolutely incredible! We all loved it.”</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"kind-card__name"} -->
<p class="kind-card__name">Kayla · Portrait from photos</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"kind-card","backgroundColor":"yellow-soft","textColor":"navy","layout":{"type":"default"}} -->
<div class="wp-block-group kind-card has-navy-color has-yellow-soft-background-color has-text-color has-background"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"kind-card__art"} -->
<figure class="wp-block-image size-large kind-card__art"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-02.webp' ); ?>" alt="Colour caricature of a woman cuddling her dog"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"kind-card__quote"} -->
<p class="kind-card__quote">“A fantastic Mother's Day present for the wife, she absolutely loved it. Will definitely be coming back for another one soon.”</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"kind-card__name"} -->
<p class="kind-card__name">Mother's Day gift</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
