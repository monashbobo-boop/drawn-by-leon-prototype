/**
 * Kind words: a pile of drawings that opens into one big drawing with its review.
 *
 * Reads plain blocks Leon edits in the editor: a group with the class "kind-words"
 * holding one group per review ("kind-card"), each with an image ("kind-card__art"),
 * a quote ("kind-card__quote") and a name ("kind-card__name"). Add, remove or reorder
 * the review groups and the pile follows.
 *
 * Tap the pile and it opens: the chosen drawing grows, its review sits beside it and
 * the other drawings line up as small frames. Tap a small frame to swap it in. The
 * same frames move each time (GSAP Flip), nothing is redrawn. Escape closes the pile,
 * arrow keys step through. Without the script the reviews simply show as cards.
 */
( function () {
	'use strict';

	var REDUCE = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	var hasFlip = !! ( window.gsap && window.Flip );
	if ( hasFlip ) {
		window.gsap.registerPlugin( window.Flip );
	}

	function text( card, cls ) {
		var el = card.querySelector( '.' + cls );
		return el ? el.textContent.trim() : '';
	}

	function setup( root ) {
		var cards = [].slice.call( root.querySelectorAll( ':scope > .kind-card' ) );
		var items = cards.map( function ( card ) {
			var img = card.querySelector( '.kind-card__art img' ) || card.querySelector( 'img' );
			return {
				img: img,
				quote: text( card, 'kind-card__quote' ),
				name: text( card, 'kind-card__name' ),
			};
		} ).filter( function ( it ) {
			return it.img;
		} );
		if ( ! items.length ) {
			return;
		}

		var n = items.length;
		var order = items.map( function ( _, i ) {
			return i;
		} );
		var opened = false;
		var busy = false;

		// Frames: one button per review, holding a copy of its drawing.
		var frames = items.map( function ( it, i ) {
			var b = document.createElement( 'button' );
			b.type = 'button';
			b.className = 'kw-frame';
			b.setAttribute( 'data-flip-id', 'kw-' + i );
			var im = document.createElement( 'img' );
			im.src = it.img.currentSrc || it.img.src;
			if ( it.img.srcset ) {
				im.srcset = it.img.srcset;
				im.sizes = '(min-width: 900px) 480px, 70vw';
			}
			im.alt = it.img.alt || '';
			im.loading = 'lazy';
			im.decoding = 'async';
			b.appendChild( im );
			b.addEventListener( 'click', function () {
				if ( ! opened ) {
					open( i );
				} else {
					choose( i );
				}
			} );
			root.appendChild( b );
			return b;
		} );

		var hint = document.createElement( 'p' );
		hint.className = 'kw-hint';
		hint.textContent = 'tap the pile to read what people say';
		root.appendChild( hint );

		var info = document.createElement( 'div' );
		info.className = 'kw-info';
		info.setAttribute( 'aria-live', 'polite' );
		info.innerHTML =
			'<p class="kw-count"></p><blockquote class="kw-quote"></blockquote><p class="kw-name"></p>' +
			'<div class="kw-tools"><button type="button" class="kw-prev" aria-label="Previous review">&larr;</button>' +
			'<button type="button" class="kw-next" aria-label="Next review">&rarr;</button>' +
			'<button type="button" class="kw-close" aria-label="Stack the reviews back up">&times;</button></div>';
		root.appendChild( info );
		info.querySelector( '.kw-prev' ).addEventListener( 'click', function () {
			choose( order[ n - 1 ] );
		} );
		info.querySelector( '.kw-next' ).addEventListener( 'click', function () {
			choose( order[ 1 ] );
		} );
		info.querySelector( '.kw-close' ).addEventListener( 'click', close );

		root.classList.add( 'is-ready' );

		function fillInfo() {
			var it = items[ order[ 0 ] ];
			var pad = function ( v ) {
				return ( v < 10 ? '0' : '' ) + v;
			};
			info.querySelector( '.kw-count' ).innerHTML = pad( order[ 0 ] + 1 ) + ' <span>/ ' + pad( n ) + '</span>';
			info.querySelector( '.kw-quote' ).textContent = it.quote;
			info.querySelector( '.kw-name' ).textContent = it.name;
			info.querySelectorAll( '.kw-prev, .kw-next' ).forEach( function ( b ) {
				b.hidden = n < 2;
			} );
			if ( hasFlip && ! REDUCE && opened ) {
				window.gsap.fromTo(
					info.querySelectorAll( '.kw-count, .kw-quote, .kw-name' ),
					{ y: 14, autoAlpha: 0 },
					{ y: 0, autoAlpha: 1, duration: 0.5, stagger: 0.07, ease: 'power3.out', delay: 0.15 }
				);
			}
		}

		function layout() {
			var W = root.clientWidth;
			var narrow = W < 760;
			var H;

			frames.forEach( function ( f, i ) {
				f.classList.toggle( 'is-hero', opened && order[ 0 ] === i );
				f.tabIndex = ! opened ? ( order[ 0 ] === i ? 0 : -1 ) : ( order[ 0 ] === i ? -1 : 0 );
				f.setAttribute(
					'aria-label',
					opened ? 'Show the review from ' + ( items[ i ].name || 'this customer' ) : 'Open the reviews, ' + n + ' in the pile'
				);
			} );

			if ( ! opened ) {
				var pw = Math.min( 270, W * 0.62 );
				var ph = pw * 1.25;
				H = ph + 110;
				order.forEach( function ( itemIndex, slot ) {
					var f = frames[ itemIndex ];
					var rot = ( slot % 2 ? 1 : -1 ) * Math.min( slot, 3 ) * 3;
					f.style.width = pw + 'px';
					f.style.height = ph + 'px';
					f.style.left = ( W - pw ) / 2 + slot * 6 + 'px';
					f.style.top = 20 + slot * 8 + 'px';
					f.style.transform = 'rotate(' + rot + 'deg)';
					f.style.zIndex = n - slot;
				} );
				hint.style.top = ph + 20 + 50 + 'px';
				root.style.height = H + 'px';
				return;
			}

			var heroW, heroH, heroX, railX, tW, tH, gap = 12, infoX, infoW, infoY;
			if ( narrow ) {
				heroW = W * 0.64;
				heroH = heroW * 1.25;
				heroX = 0;
				var rails = Math.max( n - 1, 1 );
				tH = Math.min( ( heroH - gap * ( rails - 1 ) ) / rails, ( W - heroW - 20 ) * 1.25 );
				tW = tH * 0.8;
				railX = W - tW;
				infoX = 0;
				infoW = W;
				infoY = heroH + 34;
			} else {
				heroW = Math.min( 440, W * 0.4 );
				heroH = heroW * 1.25;
				heroX = W - heroW;
				tW = Math.min( 96, W * 0.09 );
				tH = tW * 1.2;
				railX = 0;
				infoX = tW + Math.max( 40, W * 0.05 );
				infoW = heroX - infoX - Math.max( 40, W * 0.05 );
				infoY = null;
			}

			var railCount = n - 1;
			var railH = railCount * tH + ( railCount - 1 ) * gap;
			var top = narrow ? 0 : Math.max( 0, ( heroH - railH ) / 2 );

			order.forEach( function ( itemIndex, slot ) {
				var f = frames[ itemIndex ];
				f.style.transform = 'none';
				if ( slot === 0 ) {
					f.style.left = heroX + 'px';
					f.style.top = '0px';
					f.style.width = heroW + 'px';
					f.style.height = heroH + 'px';
					f.style.zIndex = n + 1;
				} else {
					f.style.left = railX + 'px';
					f.style.top = top + ( slot - 1 ) * ( tH + gap ) + 'px';
					f.style.width = tW + 'px';
					f.style.height = tH + 'px';
					f.style.zIndex = n - slot;
				}
			} );

			info.style.left = infoX + 'px';
			info.style.width = infoW + 'px';
			if ( narrow ) {
				info.style.top = infoY + 'px';
				info.style.transform = 'none';
				H = infoY + info.offsetHeight + 10;
			} else {
				info.style.top = heroH / 2 + 'px';
				info.style.transform = 'translateY(-50%)';
				H = heroH + 16;
			}
			root.style.height = H + 'px';
		}

		function animate( change, opts ) {
			if ( busy ) {
				return;
			}
			if ( ! hasFlip || REDUCE ) {
				change();
				layout();
				return;
			}
			busy = true;
			var state = window.Flip.getState( frames, { props: 'borderRadius' } );
			change();
			layout();
			window.Flip.from( state, Object.assign( {
				duration: 0.7,
				ease: 'power3.inOut',
				props: 'borderRadius',
				onComplete: function () {
					busy = false;
				},
			}, opts || {} ) );
		}

		function open( first ) {
			animate( function () {
				opened = true;
				root.classList.add( 'is-open' );
				bringToFront( first );
				fillInfo();
			}, { stagger: 0.04 } );
		}

		function choose( i ) {
			if ( i === order[ 0 ] ) {
				return;
			}
			animate( function () {
				bringToFront( i );
				fillInfo();
			} );
		}

		function close() {
			animate( function () {
				opened = false;
				root.classList.remove( 'is-open' );
			}, { stagger: { each: 0.035, from: 'end' } } );
			frames[ order[ 0 ] ].focus( { preventScroll: true } );
		}

		// The picked drawing swaps places with the big one, the rest stay put.
		function bringToFront( i ) {
			var from = order.indexOf( i );
			if ( from > 0 ) {
				order[ from ] = order[ 0 ];
				order[ 0 ] = i;
			}
		}

		root.addEventListener( 'keydown', function ( e ) {
			if ( ! opened ) {
				return;
			}
			if ( e.key === 'Escape' ) {
				close();
			} else if ( e.key === 'ArrowRight' || e.key === 'ArrowDown' ) {
				e.preventDefault();
				choose( order[ 1 ] );
			} else if ( e.key === 'ArrowLeft' || e.key === 'ArrowUp' ) {
				e.preventDefault();
				choose( order[ n - 1 ] );
			}
		} );

		var t;
		window.addEventListener( 'resize', function () {
			clearTimeout( t );
			t = setTimeout( layout, 120 );
		} );

		layout();
		frames.forEach( function ( f ) {
			f.querySelector( 'img' ).addEventListener( 'load', function () {
				if ( opened ) {
					layout();
				}
			} );
		} );
	}

	function init() {
		document.querySelectorAll( '.kind-words' ).forEach( setup );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
