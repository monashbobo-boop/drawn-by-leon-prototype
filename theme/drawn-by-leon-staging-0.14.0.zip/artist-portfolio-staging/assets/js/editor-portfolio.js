/**
 * Editor helper for the Portfolio page.
 *
 * Adds a "Portfolio filter" panel to the page settings sidebar (Page tab). It lists
 * every Gallery block that has an HTML anchor inside the "works-grid" group, with
 * the number of drawings in each. Click one to show only that gallery in the editor,
 * the same way visitors filter the page; click "All" to see everything again.
 * Nothing is saved: it only changes what the editor shows while you work.
 */
( function ( wp ) {
	if ( ! wp || ! wp.plugins || ! wp.data || ! wp.element ) {
		return;
	}
	var el = wp.element.createElement;
	var useState = wp.element.useState;
	var useEffect = wp.element.useEffect;
	var useSelect = wp.data.useSelect;
	var Panel = ( wp.editor && wp.editor.PluginDocumentSettingPanel ) || ( wp.editPost && wp.editPost.PluginDocumentSettingPanel );
	var Button = wp.components.Button;
	if ( ! Panel ) {
		return;
	}

	function findGalleries( blocks, inGrid, out ) {
		blocks.forEach( function ( b ) {
			var cls = ( b.attributes && b.attributes.className ) || '';
			var here = inGrid || /(^|\s)works-grid(\s|$)/.test( cls );
			if ( here && b.name === 'core/gallery' ) {
				out.push( {
					id: b.clientId,
					anchor: b.attributes.anchor || '',
					count: ( b.innerBlocks || [] ).length,
				} );
			}
			if ( b.innerBlocks && b.innerBlocks.length ) {
				findGalleries( b.innerBlocks, here, out );
			}
		} );
		return out;
	}

	var LABELS = {
		live: 'Live in colour',
		'live-bw': 'Live in black & white',
		'from-photos': 'From photos',
		digital: 'Digital',
		celebrity: 'Celebrity caricatures',
	};

	function canvasDocs() {
		var docs = [ document ];
		document.querySelectorAll( 'iframe[name="editor-canvas"]' ).forEach( function ( f ) {
			try {
				if ( f.contentDocument ) {
					docs.push( f.contentDocument );
				}
			} catch ( e ) {}
		} );
		return docs;
	}

	function applyFilter( galleries, which ) {
		var css = which === 'all' ? '' : galleries.filter( function ( g ) {
			return g.anchor !== which;
		} ).map( function ( g ) {
			return '#block-' + g.id;
		} ).join( ',' ) + '{display:none!important}';
		canvasDocs().forEach( function ( doc ) {
			var tag = doc.getElementById( 'leon-portfolio-filter' );
			if ( ! tag ) {
				tag = doc.createElement( 'style' );
				tag.id = 'leon-portfolio-filter';
				( doc.head || doc.documentElement ).appendChild( tag );
			}
			tag.textContent = which === 'all' || ! galleries.length ? '' : css;
		} );
	}

	function FilterPanel() {
		var galleries = useSelect( function ( select ) {
			return findGalleries( select( 'core/block-editor' ).getBlocks(), false, [] );
		}, [] );
		var state = useState( 'all' );
		var which = state[ 0 ];
		var setWhich = state[ 1 ];

		useEffect( function () {
			applyFilter( galleries, which );
			// The editor canvas can be rebuilt (device preview, zoom), so re-apply shortly after.
			var t = setTimeout( function () {
				applyFilter( galleries, which );
			}, 400 );
			return function () {
				clearTimeout( t );
			};
		}, [ which, galleries ] );

		if ( ! galleries.length ) {
			return null;
		}

		var total = galleries.reduce( function ( a, g ) {
			return a + g.count;
		}, 0 );

		function item( key, label, count ) {
			return el(
				Button,
				{
					key: key,
					variant: which === key ? 'primary' : 'secondary',
					onClick: function () {
						setWhich( key );
					},
					style: { justifyContent: 'space-between', width: '100%', marginBottom: '6px' },
				},
				el( 'span', null, label ),
				el( 'span', { style: { opacity: 0.7 } }, String( count ) )
			);
		}

		return el(
			Panel,
			{ name: 'leon-portfolio-filter', title: 'Portfolio filter', initialOpen: true },
			el( 'p', { style: { marginTop: 0 } }, 'Show one gallery while you edit. Visitors still see the filter buttons.' ),
			item( 'all', 'All', total ),
			galleries.map( function ( g ) {
				return item( g.anchor || g.id, LABELS[ g.anchor ] || g.anchor || 'Gallery without anchor', g.count );
			} )
		);
	}

	wp.plugins.registerPlugin( 'leon-portfolio-filter', { render: FilterPanel } );
} )( window.wp );
