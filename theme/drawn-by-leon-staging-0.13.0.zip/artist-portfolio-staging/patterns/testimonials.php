<?php
/**
 * Title: Testimonials: card stack
 * Slug: artist-portfolio/testimonials
 * Categories: artist-sections, testimonials
 * Description: Reviews on a pile of cards that fans out when it scrolls into view (on phones, tap the top card to see the next). Each card is a group: change its colour, icon, quote and name. The quotes are labelled samples: swap in real reviews and names before launch.
 * Keywords: reviews, testimonials, quotes, clients, cards
 */
?>
<!-- wp:group {"align":"full","className":"testimonials","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull testimonials" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:paragraph {"align":"center","className":"hand-note is-small","textColor":"navy-soft"} -->
<p class="has-text-align-center hand-note is-small has-navy-soft-color has-text-color">what people say</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-text-align-center has-xx-large-font-size">Kind words</h2>
<!-- /wp:heading -->

<!-- wp:group {"align":"wide","className":"card-stack","style":{"spacing":{"margin":{"top":"var:preset|spacing|50"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide card-stack" style="margin-top:var(--wp--preset--spacing--50)"><!-- wp:group {"className":"stack-card","backgroundColor":"yellow","textColor":"navy","layout":{"type":"default"}} -->
<div class="wp-block-group stack-card has-navy-color has-yellow-background-color has-text-color has-background"><!-- wp:image {"lightbox":{"enabled":false},"width":"52px","sizeSlug":"full","className":"stack-card__icon"} -->
<figure class="wp-block-image size-full is-resized stack-card__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-wedding.webp' ); ?>" alt="" style="width:52px"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"stack-card__quote","fontSize":"large"} -->
<p class="stack-card__quote has-large-font-size">“We can't thank you enough for all your efforts last night! All the guests absolutely loved them and it's something we will all cherish.”</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"stack-card__name","fontSize":"small"} -->
<p class="stack-card__name has-small-font-size">Bita · Wedding</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"stack-card","backgroundColor":"navy","textColor":"white","layout":{"type":"default"}} -->
<div class="wp-block-group stack-card has-white-color has-navy-background-color has-text-color has-background"><!-- wp:image {"lightbox":{"enabled":false},"width":"52px","sizeSlug":"full","className":"stack-card__icon"} -->
<figure class="wp-block-image size-full is-resized stack-card__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-community.webp' ); ?>" alt="" style="width:52px"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"stack-card__quote","fontSize":"large"} -->
<p class="stack-card__quote has-large-font-size">“We appreciate your dedication and amazing work! Everyone loved their picture. We are so happy to have met you.”</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"stack-card__name","fontSize":"small"} -->
<p class="stack-card__name has-small-font-size">Trang &amp; Eva · Party</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"stack-card","backgroundColor":"white","textColor":"navy","layout":{"type":"default"}} -->
<div class="wp-block-group stack-card has-navy-color has-white-background-color has-text-color has-background"><!-- wp:image {"lightbox":{"enabled":false},"width":"52px","sizeSlug":"full","className":"stack-card__icon"} -->
<figure class="wp-block-image size-full is-resized stack-card__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-photo.webp' ); ?>" alt="" style="width:52px"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"stack-card__quote","fontSize":"large"} -->
<p class="stack-card__quote has-large-font-size">“Thank you so much for the drawing of our dad and animals. It's absolutely incredible! We all loved it.”</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"stack-card__name","fontSize":"small"} -->
<p class="stack-card__name has-small-font-size">Kayla · Portrait from photos</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"stack-card","backgroundColor":"yellow-soft","textColor":"navy","layout":{"type":"default"}} -->
<div class="wp-block-group stack-card has-navy-color has-yellow-soft-background-color has-text-color has-background"><!-- wp:image {"lightbox":{"enabled":false},"width":"52px","sizeSlug":"full","className":"stack-card__icon"} -->
<figure class="wp-block-image size-full is-resized stack-card__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-birthday.webp' ); ?>" alt="" style="width:52px"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"stack-card__quote","fontSize":"large"} -->
<p class="stack-card__quote has-large-font-size">“A fantastic Mother's Day present for the wife, she absolutely loved it. Will definitely be coming back for another one soon.”</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"stack-card__name","fontSize":"small"} -->
<p class="stack-card__name has-small-font-size">Mother's Day gift</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
