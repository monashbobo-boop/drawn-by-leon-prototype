<?php
/**
 * Title: About: who's Leon
 * Slug: artist-portfolio/about-head
 * Categories: artist-sections, about
 * Description: Big question title with a spinning sticker, Leon's story, and his character beside it.
 * Keywords: about, bio, story, title
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60","top":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"60%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:60%"><!-- wp:paragraph {"className":"hand-note is-small","textColor":"navy-soft"} -->
<p class="hand-note is-small has-navy-soft-color has-text-color">nice to meet you!</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"page-title","fontSize":"giant"} -->
<h1 class="wp-block-heading page-title has-giant-font-size">Who's Leon?!</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">I'm Leon, a caricature artist based in Melbourne. I've loved drawing since childhood, especially observing faces and capturing the features that make each person unique.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>After more than ten years as an art teacher, I now specialise in live caricatures and custom portraits from photos. I draw at weddings, parties, festivals and community events, and create personalised portraits for gifts and keepsakes.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>My style is detailed and charming, with gentle exaggeration that keeps each person recognisable. My favourite moment is when someone sees themselves in the drawing and breaks into a smile.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Every portrait tells a little story about a person, a relationship or a special occasion. I hope my drawings bring joy and become something people take home and treasure for years.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"40%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:40%"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full","className":"about-photo"} -->
<figure class="wp-block-image size-full about-photo"><img src="<?php echo artist_portfolio_image( 'photos/leon-drawing-wedding.webp' ); ?>" alt="Leon drawing a guest at a wedding reception while guests watch"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
