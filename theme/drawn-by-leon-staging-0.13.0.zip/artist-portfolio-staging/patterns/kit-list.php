<?php
/**
 * Title: About: in my bag
 * Slug: artist-portfolio/kit-list
 * Categories: artist-sections, text
 * Description: Four big titles with doodle icons. Click a title and its text opens in a blue panel below. Each row is a group: swap the icon, title and text in the editor.
 * Keywords: kit, tools, materials, how I draw, accordion
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:paragraph {"className":"hand-note","textColor":"navy-soft"} -->
<p class="hand-note has-navy-soft-color has-text-color">what's in my bag?</p>
<!-- /wp:paragraph -->

<!-- wp:group {"align":"wide","className":"reveal-list","style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide reveal-list" style="margin-top:var(--wp--preset--spacing--40)"><!-- wp:group {"className":"reveal-row","layout":{"type":"default"}} -->
<div class="wp-block-group reveal-row"><!-- wp:group {"className":"reveal-row__head","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reveal-row__head"><!-- wp:image {"lightbox":{"enabled":false},"width":"96px","sizeSlug":"full","className":"reveal-row__icon"} -->
<figure class="wp-block-image size-full is-resized reveal-row__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-paper.webp' ); ?>" alt="" style="width:96px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"reveal-row__title","fontSize":"xx-large"} -->
<h3 class="wp-block-heading reveal-row__title has-xx-large-font-size">A stack of A4 paper</h3>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal-row__panel","backgroundColor":"navy","textColor":"white","layout":{"type":"default"}} -->
<div class="wp-block-group reveal-row__panel has-white-color has-navy-background-color has-text-color has-background"><!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">At events every guest gets their drawing on A4 paper, ready to take home. Portraits from photos are drawn on A3.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal-row","layout":{"type":"default"}} -->
<div class="wp-block-group reveal-row"><!-- wp:group {"className":"reveal-row__head","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reveal-row__head"><!-- wp:image {"lightbox":{"enabled":false},"width":"96px","sizeSlug":"full","className":"reveal-row__icon"} -->
<figure class="wp-block-image size-full is-resized reveal-row__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-marker.webp' ); ?>" alt="" style="width:96px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"reveal-row__title","fontSize":"xx-large"} -->
<h3 class="wp-block-heading reveal-row__title has-xx-large-font-size">Markers and pencils</h3>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal-row__panel","backgroundColor":"navy","textColor":"white","layout":{"type":"default"}} -->
<div class="wp-block-group reveal-row__panel has-white-color has-navy-background-color has-text-color has-background"><!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Black markers for bold black and white drawings, plus colour markers and pencils when you want full colour.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal-row","layout":{"type":"default"}} -->
<div class="wp-block-group reveal-row"><!-- wp:group {"className":"reveal-row__head","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reveal-row__head"><!-- wp:image {"lightbox":{"enabled":false},"width":"96px","sizeSlug":"full","className":"reveal-row__icon"} -->
<figure class="wp-block-image size-full is-resized reveal-row__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-easel.webp' ); ?>" alt="" style="width:96px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"reveal-row__title","fontSize":"xx-large"} -->
<h3 class="wp-block-heading reveal-row__title has-xx-large-font-size">My own easel and setup</h3>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal-row__panel","backgroundColor":"navy","textColor":"white","layout":{"type":"default"}} -->
<div class="wp-block-group reveal-row__panel has-white-color has-navy-background-color has-text-color has-background"><!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">I bring the drawing materials and paper. All I need is a well-lit spot that's easy for guests to reach, with room for seating.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal-row","layout":{"type":"default"}} -->
<div class="wp-block-group reveal-row"><!-- wp:group {"className":"reveal-row__head","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group reveal-row__head"><!-- wp:image {"lightbox":{"enabled":false},"width":"96px","sizeSlug":"full","className":"reveal-row__icon"} -->
<figure class="wp-block-image size-full is-resized reveal-row__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-palette.webp' ); ?>" alt="" style="width:96px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"reveal-row__title","fontSize":"xx-large"} -->
<h3 class="wp-block-heading reveal-row__title has-xx-large-font-size">Black and white, or full colour</h3>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"reveal-row__panel","backgroundColor":"navy","textColor":"white","layout":{"type":"default"}} -->
<div class="wp-block-group reveal-row__panel has-white-color has-navy-background-color has-text-color has-background"><!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Black and white is quicker, around 12 to 15 people an hour. Colour is richer, about 8 to 10 people an hour.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
