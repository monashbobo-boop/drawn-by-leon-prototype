<?php
/**
 * Title: Page: Live caricatures
 * Slug: artist-portfolio/page-events
 * Categories: artist-pages
 * Block Types: core/post-content
 * Post Types: page
 * Viewport Width: 1400
 * Description: Title and intro, event types, why Leon, black and white versus colour, how-long-to-book calculator, service details, how to book, FAQ and closing band.
 */
?>
<!-- wp:pattern {"slug":"artist-portfolio/events-head"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/event-types"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/why-leon"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/style-compare"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/guest-calc"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/event-details"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/how-it-works"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/faq"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/events-cta"} /-->
