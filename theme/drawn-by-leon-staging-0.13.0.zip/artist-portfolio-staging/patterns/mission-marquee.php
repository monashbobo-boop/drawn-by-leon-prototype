<?php
/**
 * Title: About: statement band
 * Slug: artist-portfolio/mission-marquee
 * Categories: artist-sections, banner
 * Description: Yellow band with one big sentence, a handwritten note and two doodles. Nothing moves.
 * Keywords: mission, statement, banner
 */
?>
<!-- wp:group {"align":"full","className":"statement-band","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"yellow","textColor":"navy","layout":{"type":"constrained","contentSize":"980px"}} -->
<div class="wp-block-group alignfull statement-band has-navy-color has-yellow-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:image {"lightbox":{"enabled":false},"width":"96px","sizeSlug":"full","className":"statement-band__doodle is-left"} -->
<figure class="wp-block-image size-full is-resized statement-band__doodle is-left"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-photo.webp' ); ?>" alt="" style="width:96px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","className":"has-heart","fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-text-align-center has-heart has-xx-large-font-size">Detailed, charming and unmistakably you</h2>
<!-- /wp:heading -->

<!-- wp:image {"lightbox":{"enabled":false},"width":"96px","sizeSlug":"full","className":"statement-band__doodle is-right"} -->
<figure class="wp-block-image size-full is-resized statement-band__doodle is-right"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-live-portrait.webp' ); ?>" alt="" style="width:96px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->
