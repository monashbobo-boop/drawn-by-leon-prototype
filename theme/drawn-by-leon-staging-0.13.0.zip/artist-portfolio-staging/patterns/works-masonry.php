<?php
/**
 * Title: Portfolio: masonry galleries
 * Slug: artist-portfolio/works-masonry
 * Categories: artist-sections, gallery
 * Description: Filter buttons and galleries built from the Media Library. Give an image a Portfolio category (Media > Library > edit image) and it appears here, newest first. Categories are listed in the order they were created; the first one opens first.
 * Keywords: portfolio, gallery, masonry, works
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:shortcode -->
[leon_portfolio]
<!-- /wp:shortcode --></div>
<!-- /wp:group -->
