<?php
/**
 * Title: How it works: live events
 * Slug: artist-portfolio/how-it-works
 * Categories: artist-sections, text
 * Description: Blue panel with the four steps of booking Leon for an event.
 * Keywords: steps, process, how it works, booking, live
 */
?>
<!-- wp:group {"align":"full","className":"is-style-panel has-star","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull is-style-panel has-star" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">How to book</h2>
<!-- /wp:heading -->

<!-- wp:columns {"align":"wide","style":{"spacing":{"margin":{"top":"var:preset|spacing|50"},"blockGap":{"left":"var:preset|spacing|50","top":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide" style="margin-top:var(--wp--preset--spacing--50)">
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"step-head","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group step-head"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">1</p>
<!-- /wp:paragraph -->

<!-- wp:image {"lightbox":{"enabled":false},"width":"84px","sizeSlug":"full","className":"step-icon"} -->
<figure class="wp-block-image size-full is-resized step-icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-contact.webp' ); ?>" alt="" style="width:84px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Tell me about your event</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Send your event date, location, event type, expected guest numbers and preferred booking length.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"step-head","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group step-head"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">2</p>
<!-- /wp:paragraph -->

<!-- wp:image {"lightbox":{"enabled":false},"width":"84px","sizeSlug":"full","className":"step-icon"} -->
<figure class="wp-block-image size-full is-resized step-icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-quote.webp' ); ?>" alt="" style="width:84px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Discuss the details</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>We'll agree on black and white or colour, estimate how many guests can be drawn and discuss the setup. I'll then provide a quote.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"step-head","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group step-head"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">3</p>
<!-- /wp:paragraph -->

<!-- wp:image {"lightbox":{"enabled":false},"width":"84px","sizeSlug":"full","className":"step-icon"} -->
<figure class="wp-block-image size-full is-resized step-icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-calendar.webp' ); ?>" alt="" style="width:84px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Confirm your booking</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Once we've agreed on the service, quote and payment arrangements, I'll explain the steps to secure your booking.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"step-head","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group step-head"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">4</p>
<!-- /wp:paragraph -->

<!-- wp:image {"lightbox":{"enabled":false},"width":"84px","sizeSlug":"full","className":"step-icon"} -->
<figure class="wp-block-image size-full is-resized step-icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-live-portrait.webp' ); ?>" alt="" style="width:84px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Enjoy the drawing on the day</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Your guests sit for their portraits, watch the artwork come to life and take their drawings home.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|50"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--50)"><!-- wp:button {"backgroundColor":"yellow","textColor":"navy"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-navy-color has-yellow-background-color has-text-color has-background wp-element-button" href="/contact/#event">Check Availability and Get a Quote</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
