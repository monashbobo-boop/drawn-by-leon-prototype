<?php
/**
 * Title: Live events: service details
 * Slug: artist-portfolio/event-details
 * Categories: artist-sections, services
 * Description: Service details as a two-column table (item and details) with a short note underneath. Edit the cells in place.
 * Keywords: details, table, included, booking, area
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1100px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60","top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"32%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:32%"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Service details</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"hand-note is-small","textColor":"navy-soft"} -->
<p class="hand-note is-small has-navy-soft-color has-text-color">prices depend on your event, so ask me for a quote</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"68%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:68%"><!-- wp:table {"className":"details-table"} -->
<figure class="wp-block-table details-table"><table><tbody><tr><td>Drawing format</td><td>Hand-drawn on A4 paper, in black and white or colour</td></tr><tr><td>Drawing rate</td><td>Around 12-15 people per hour in black and white, or 8-10 in colour</td></tr><tr><td>Group portraits</td><td>One or two people per A4 sheet recommended. Larger groups can be discussed in advance.</td></tr><tr><td>Minimum booking</td><td>Two hours</td></tr><tr><td>Included</td><td>Paper and drawing materials. Guests keep their original artwork.</td></tr><tr><td>Service area</td><td>Melbourne and surrounding areas. Other locations by enquiry.</td></tr></tbody></table></figure>
<!-- /wp:table --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
