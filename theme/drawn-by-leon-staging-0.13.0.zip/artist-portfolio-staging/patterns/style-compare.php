<?php
/**
 * Title: Events: black and white or colour
 * Slug: artist-portfolio/style-compare
 * Categories: artist-sections, text
 * Description: A black and white drawing and a colour drawing side by side, each with how many people an hour that style suits and one line. Swap either image in the editor.
 * Keywords: style, colour, black and white, speed
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1100px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:paragraph {"align":"center","className":"hand-note is-small","textColor":"navy-soft"} -->
<p class="has-text-align-center hand-note is-small has-navy-soft-color has-text-color">guests drawn per hour</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-text-align-center has-xx-large-font-size">Black &amp; white or colour?</h2>
<!-- /wp:heading -->

<!-- wp:columns {"className":"style-compare","style":{"spacing":{"margin":{"top":"var:preset|spacing|50"},"blockGap":{"left":"var:preset|spacing|70","top":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns style-compare" style="margin-top:var(--wp--preset--spacing--50)"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"style-compare__art"} -->
<figure class="wp-block-image size-large style-compare__art"><img src="<?php echo artist_portfolio_image( 'works/live-bw/live-bw-05.webp' ); ?>" alt="Black and white live caricature of a smiling woman with sunglasses on her head"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"big-stat"} -->
<p class="big-stat">12–15 <span>people per hour</span></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"style-compare__art"} -->
<figure class="wp-block-image size-large style-compare__art"><img src="<?php echo artist_portfolio_image( 'works/live-colour/live-colour-39.webp' ); ?>" alt="The same woman drawn live in colour"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"big-stat"} -->
<p class="big-stat">8–10 <span>people per hour</span></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
