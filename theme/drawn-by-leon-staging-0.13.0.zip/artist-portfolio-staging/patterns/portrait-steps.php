<?php
/**
 * Title: Custom portraits: how to order
 * Slug: artist-portfolio/portrait-steps
 * Categories: artist-sections, about
 * Description: Four numbered steps for ordering a portrait from photos, on a navy panel, with the enquiry button.
 * Keywords: steps, process, order, how
 */
?>
<!-- wp:group {"align":"full","className":"is-style-panel has-star","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull is-style-panel has-star" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">How to order</h2>
<!-- /wp:heading -->

<!-- wp:columns {"align":"wide","style":{"spacing":{"margin":{"top":"var:preset|spacing|50"},"blockGap":{"left":"var:preset|spacing|50","top":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide" style="margin-top:var(--wp--preset--spacing--50)">
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"step-head","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group step-head"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">1</p>
<!-- /wp:paragraph -->

<!-- wp:image {"lightbox":{"enabled":false},"width":"84px","sizeSlug":"full","className":"step-icon"} -->
<figure class="wp-block-image size-full is-resized step-icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-photo-upload.webp' ); ?>" alt="" style="width:84px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Send your photos and ideas</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Let me know how many people you'd like drawn, whether you prefer black and white or colour, your preferred format and when you need the portrait. Include any requests for clothing, a body, a background or a theme.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"step-head","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group step-head"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">2</p>
<!-- /wp:paragraph -->

<!-- wp:image {"lightbox":{"enabled":false},"width":"84px","sizeSlug":"full","className":"step-icon"} -->
<figure class="wp-block-image size-full is-resized step-icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-quote.webp' ); ?>" alt="" style="width:84px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Confirm the details and quote</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>I'll check your photos and confirm the artwork, completion time, delivery method and total price with you.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"step-head","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group step-head"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">3</p>
<!-- /wp:paragraph -->

<!-- wp:image {"lightbox":{"enabled":false},"width":"84px","sizeSlug":"full","className":"step-icon"} -->
<figure class="wp-block-image size-full is-resized step-icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-payment.webp' ); ?>" alt="" style="width:84px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Make payment</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Once payment has been made according to the agreed arrangements, I'll begin your portrait.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"step-head","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group step-head"><!-- wp:paragraph {"className":"step-number"} -->
<p class="step-number">4</p>
<!-- /wp:paragraph -->

<!-- wp:image {"lightbox":{"enabled":false},"width":"84px","sizeSlug":"full","className":"step-icon"} -->
<figure class="wp-block-image size-full is-resized step-icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-delivery.webp' ); ?>" alt="" style="width:84px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Receive your portrait</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Your original artwork will be posted as agreed, or your digital file will be sent by email.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|50"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--50)"><!-- wp:button {"backgroundColor":"yellow","textColor":"navy"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-navy-color has-yellow-background-color has-text-color has-background wp-element-button" href="/contact/#photo">Enquire About a Portrait</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
