<?php
/**
 * Title: Custom portraits: service details
 * Slug: artist-portfolio/portrait-details
 * Categories: artist-sections, services
 * Description: Service details for portraits from photos as a two-column table, with a note on postage time.
 * Keywords: details, table, turnaround, delivery, postage
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1100px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60","top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"32%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:32%"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Service details</h2>
<!-- /wp:heading -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full","className":"details-mascot"} -->
<figure class="wp-block-image size-full details-mascot"><img src="<?php echo artist_portfolio_image( 'brand/mascot-sketching.webp' ); ?>" alt="Leon's cartoon self sitting in a director's chair, sketching on a clipboard"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"68%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:68%"><!-- wp:table {"className":"details-table"} -->
<figure class="wp-block-table details-table"><table><tbody><tr><td>Artwork format</td><td>A3 original on paper or a digital file</td></tr><tr><td>Style</td><td>Black and white or colour</td></tr><tr><td>People</td><td>Individuals, couples, friends or families</td></tr><tr><td>Completion time</td><td>Usually within five business days once photos, requirements and payment are confirmed</td></tr><tr><td>Personalisation</td><td>Clothing requests, or an added body, background or theme. Any additional costs are confirmed in advance.</td></tr><tr><td>Delivery</td><td>Originals can be posted. Digital files are sent by email.</td></tr><tr><td>Postage</td><td>Confirmed in your quote based on your address and delivery method</td></tr></tbody></table></figure>
<!-- /wp:table --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
