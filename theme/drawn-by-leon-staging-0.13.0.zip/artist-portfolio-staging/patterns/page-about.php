<?php
/**
 * Title: Page: About
 * Slug: artist-portfolio/page-about
 * Categories: artist-pages
 * Block Types: core/post-content
 * Post Types: page
 * Viewport Width: 1400
 * Description: Who's Leon title with sticker and story, a giant scrolling line, what's in my bag, and the shows he has drawn at.
 */
?>
<!-- wp:pattern {"slug":"artist-portfolio/about-head"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/mission-marquee"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/kit-list"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/shows-panel"} /-->
