<?php
/**
 * Title: Live events: title and intro
 * Slug: artist-portfolio/events-head
 * Categories: artist-sections, header
 * Description: Page title on the left; the tagline, two short paragraphs and a button on the right.
 * Keywords: title, intro, live, events
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:group {"align":"wide","className":"event-snaps","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide event-snaps"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"event-snaps__photo"} -->
<figure class="wp-block-image size-large event-snaps__photo"><img src="<?php echo artist_portfolio_image( 'photos/event-leon-booth.webp' ); ?>" alt="Leon drawing a guest at his night market stall"/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"event-snaps__photo"} -->
<figure class="wp-block-image size-large event-snaps__photo"><img src="<?php echo artist_portfolio_image( 'photos/event-wedding-guests.webp' ); ?>" alt="Three wedding guests holding up their caricature"/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"event-snaps__photo"} -->
<figure class="wp-block-image size-large event-snaps__photo"><img src="<?php echo artist_portfolio_image( 'photos/event-wedding-drawing.webp' ); ?>" alt="Leon drawing live at a wedding reception"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:columns {"verticalAlignment":"top","align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60","top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-top"><!-- wp:column {"verticalAlignment":"top","width":"52%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:52%"><!-- wp:paragraph {"className":"hand-note is-small","textColor":"navy-soft"} -->
<p class="hand-note is-small has-navy-soft-color has-text-color">weddings, parties, work dos</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"page-title","fontSize":"giant"} -->
<h1 class="wp-block-heading page-title has-giant-font-size">Live caricatures</h1>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"top","width":"48%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:48%"><!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size"><strong>A little fun on the day and a keepsake to take home</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Bring a personal touch to your event with live caricature drawing. I create charming, detailed portraits of your guests, using gentle exaggeration to capture their individual features while keeping them recognisable.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Guests can sit for a portrait or watch the drawings take shape, sharing a laugh as they recognise themselves and their friends. Each guest takes home their original artwork as a lasting reminder of the occasion.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40)"><!-- wp:button {"backgroundColor":"yellow","textColor":"navy"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-navy-color has-yellow-background-color has-text-color has-background wp-element-button" href="/contact/#event">Check Availability and Get a Quote</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
