<?php
/**
 * Title: Your face here: colour in a drawing
 * Slug: artist-portfolio/face-here
 * Categories: artist-sections, featured
 * Description: The "Your face here?" sketchpad. The big sheet on the left is an image block with the Drawing reveal style and the "is-sheet" class: visitors tap it and colour the drawing in by hand. Swap that image for any colour caricature with a transparent background. Two smaller stickers sit beside it.
 * Keywords: interactive, drawing, colour, sketchpad, your face here
 */
?>
<!-- wp:group {"align":"full","className":"face-here","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull face-here" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|70","top":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%"><!-- wp:group {"className":"face-here__desk","layout":{"type":"default"}} -->
<div class="wp-block-group face-here__desk"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full","className":"is-style-draw-reveal is-sheet"} -->
<figure class="wp-block-image size-full is-style-draw-reveal is-sheet"><img src="<?php echo artist_portfolio_image( 'works/celebrity/mr-bean.webp' ); ?>" alt="Colour caricature of Mr Bean in his brown jacket and red tie"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%"><!-- wp:paragraph {"className":"hand-note is-small","textColor":"red"} -->
<p class="hand-note is-small has-red-color has-text-color">go on, have a go</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"className":"face-here__title","fontSize":"xx-large"} -->
<h2 class="wp-block-heading face-here__title has-xx-large-font-size">Your face here?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Every caricature starts as a light pencil sketch. Tap the sheet, pick up the marker and colour one of my drawings in yourself.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>At your event I do the colouring, of course. Guests sit down, smile, and watch their own portrait come together line by line.</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"fact-list"} -->
<ul class="wp-block-list fact-list"><!-- wp:list-item -->
<li><strong>12–15</strong> people an hour in black and white</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>8–10</strong> people an hour in colour</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40)"><!-- wp:button {"backgroundColor":"yellow","textColor":"navy"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-navy-color has-yellow-background-color has-text-color has-background wp-element-button" href="/contact/#event">Book an event</a></div>
<!-- /wp:button -->

<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/custom-portraits/">Order a portrait</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
