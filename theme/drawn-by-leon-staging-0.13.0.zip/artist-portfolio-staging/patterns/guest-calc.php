<?php
/**
 * Title: Events: how long should I book?
 * Slug: artist-portfolio/guest-calc
 * Categories: artist-sections, text
 * Description: Interactive guide in a blue panel: visitors set their guest numbers and drawing style and see how long to book. Without JavaScript it shows the guide text only.
 * Keywords: calculator, hours, guests, booking
 */
?>
<!-- wp:group {"align":"full","className":"is-style-panel","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1100px"}} -->
<div class="wp-block-group alignfull is-style-panel" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60","top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"42%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:42%"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">How long should I book?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Move the slider to your guest numbers. As a guide I draw 12 to 15 guests an hour in black and white, 8 to 10 in colour, and bookings start from 2 hours.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"58%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:58%"><!-- wp:group {"className":"guest-calc","layout":{"type":"default"}} -->
<div class="wp-block-group guest-calc"></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
