<?php
/**
 * Title: Gallery preview
 * Slug: artist-portfolio/gallery-preview
 * Categories: artist-sections, gallery
 * Description: A row of recent drawings in a scattered gallery with a link to the full portfolio. Add or swap images in the editor.
 * Keywords: gallery, portfolio, works, artwork
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:paragraph {"align":"center","className":"hand-note is-small","textColor":"navy-soft"} -->
<p class="has-text-align-center hand-note is-small has-navy-soft-color has-text-color">fresh off the sketchpad</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-text-align-center has-xx-large-font-size">Recent drawings</h2>
<!-- /wp:heading -->

<!-- wp:gallery {"columns":3,"linkTo":"none","sizeSlug":"large","align":"wide","className":"is-style-scatter is-rotator","style":{"spacing":{"margin":{"top":"var:preset|spacing|50"},"blockGap":{"top":"var:preset|spacing|40","left":"var:preset|spacing|40"}}}} -->
<figure class="wp-block-gallery alignwide has-nested-images columns-3 is-cropped is-style-scatter is-rotator" style="margin-top:var(--wp--preset--spacing--50)"><!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-01.webp' ); ?>" alt="Colour wedding caricature of a bride and a bearded groom holding roses"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-02.webp' ); ?>" alt="Colour caricature of a woman cuddling her fluffy dog"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-03.webp' ); ?>" alt="Birthday caricature of a smiling woman sitting in a giant strawberry cake"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-04.webp' ); ?>" alt="Colour 40th birthday portrait of a man in overalls"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/live-colour/live-colour-34.webp' ); ?>" alt="Colour caricature of a mother and her two daughters"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-16.webp' ); ?>" alt="Colour birthday portrait of a grandfather and grandson on a hill"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/live-colour/live-colour-35.webp' ); ?>" alt="Colour caricature of a couple with a big red heart"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-12.webp' ); ?>" alt="Colour portrait of a bearded man in a beanie hugging his dog"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/live-colour/live-colour-37.webp' ); ?>" alt="Colour caricature of a smiling man in glasses"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/live-colour/live-colour-33.webp' ); ?>" alt="Colour caricature of a smiling couple"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-10.webp' ); ?>" alt="Colour portrait of a little girl with pigtails holding a star wand"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/live-colour/live-colour-26.webp' ); ?>" alt="Colour caricature of a couple, a bearded man and a woman"/></figure>
<!-- /wp:image --></figure>
<!-- /wp:gallery -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|50"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--50)"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/portfolio/">See the full portfolio</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
