<?php
/**
 * Title: Custom portraits: recent portraits
 * Slug: artist-portfolio/portrait-gallery
 * Categories: artist-sections, gallery
 * Description: Six recent portraits from photos as small tiles (tap to enlarge), with a link to the full portfolio.
 * Keywords: gallery, portraits, recent, examples
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:paragraph {"className":"hand-note is-small","textColor":"navy-soft"} -->
<p class="hand-note is-small has-navy-soft-color has-text-color">a few I drew lately</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Recent portraits</h2>
<!-- /wp:heading -->

<!-- wp:gallery {"columns":6,"linkTo":"none","sizeSlug":"large","align":"wide","className":"is-style-masonry","style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<figure class="wp-block-gallery alignwide has-nested-images columns-6 is-cropped is-style-masonry" style="margin-top:var(--wp--preset--spacing--40)"><!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/live-colour/live-colour-47.webp' ); ?>" alt="Colour portrait of a bearded man in a black cap, on blue paper"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-06.webp' ); ?>" alt="Colour portrait of a smiling boy holding Lego, with his name and a sunshine"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-14.webp' ); ?>" alt="Colour portrait of a couple riding a rainbow unicorn through the clouds"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-04.webp' ); ?>" alt="Colour 40th birthday portrait of a woman in overalls"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-12.webp' ); ?>" alt="Colour portrait of a bearded man in a beanie hugging his dachshund"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-10.webp' ); ?>" alt="Colour portrait of a little girl with pigtails holding a star wand"/></figure>
<!-- /wp:image --></figure>
<!-- /wp:gallery -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40)"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/portfolio/#from-photos">See more portraits</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
