<?php
/**
 * Title: Page: Portfolio
 * Slug: artist-portfolio/page-portfolio
 * Categories: artist-pages
 * Block Types: core/post-content
 * Post Types: page
 * Viewport Width: 1400
 * Description: Outlined-number title and ticker, then masonry galleries with hover captions.
 */
?>
<!-- wp:pattern {"slug":"artist-portfolio/portfolio-head"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/works-masonry"} /-->
