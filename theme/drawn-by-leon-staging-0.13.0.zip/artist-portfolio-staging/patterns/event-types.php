<?php
/**
 * Title: Live events: perfect for your event
 * Slug: artist-portfolio/event-types
 * Categories: artist-sections, services
 * Description: Four event types, each with one of Leon's hand-drawn icons, a title and one line. Swap an icon by replacing its image.
 * Keywords: events, weddings, birthdays, corporate, festivals, icons
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Events I draw at</h2>
<!-- /wp:heading -->

<!-- wp:group {"align":"wide","className":"type-grid","style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide type-grid" style="margin-top:var(--wp--preset--spacing--40)"><!-- wp:group {"className":"type-card","layout":{"type":"default"}} -->
<div class="wp-block-group type-card"><!-- wp:image {"lightbox":{"enabled":false},"width":"88px","sizeSlug":"full","className":"type-card__icon"} -->
<figure class="wp-block-image size-full is-resized type-card__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-wedding.webp' ); ?>" alt="" style="width:88px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Weddings</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Give your family and friends an enjoyable experience and a personal keepsake from your wedding day.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"type-card","layout":{"type":"default"}} -->
<div class="wp-block-group type-card"><!-- wp:image {"lightbox":{"enabled":false},"width":"88px","sizeSlug":"full","className":"type-card__icon"} -->
<figure class="wp-block-image size-full is-resized type-card__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-birthday.webp' ); ?>" alt="" style="width:88px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Birthdays and private parties</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A fun activity for guests of all ages, with portraits of individuals, couples and family members.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"type-card","layout":{"type":"default"}} -->
<div class="wp-block-group type-card"><!-- wp:image {"lightbox":{"enabled":false},"width":"88px","sizeSlug":"full","className":"type-card__icon"} -->
<figure class="wp-block-image size-full is-resized type-card__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-corporate.webp' ); ?>" alt="" style="width:88px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Corporate events</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Add a relaxed, interactive activity to staff gatherings, client events and Christmas parties.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"type-card","layout":{"type":"default"}} -->
<div class="wp-block-group type-card"><!-- wp:image {"lightbox":{"enabled":false},"width":"88px","sizeSlug":"full","className":"type-card__icon"} -->
<figure class="wp-block-image size-full is-resized type-card__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-market.webp' ); ?>" alt="" style="width:88px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Festivals and community events</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Give visitors the chance to enjoy live drawing and take home a portrait of their own.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
