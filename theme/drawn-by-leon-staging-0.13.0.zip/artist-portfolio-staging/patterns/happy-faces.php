<?php
/**
 * Title: Happy faces and quick facts
 * Slug: artist-portfolio/happy-faces
 * Categories: artist-sections, about
 * Description: A taped photo of happy customers with their drawing, next to quick facts about a live booking.
 * Keywords: customers, photo, facts, live, booking
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|70","top":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"42%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:42%"><!-- wp:image {"sizeSlug":"large","className":"is-style-taped"} -->
<figure class="wp-block-image size-large is-style-taped"><img src="<?php echo artist_portfolio_image( 'photos/guests-show-2.webp' ); ?>" alt="A couple at Leon's stall holding up the black and white caricature he just drew of them"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"58%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:58%"><!-- wp:paragraph {"className":"hand-note is-small","textColor":"navy-soft"} -->
<p class="hand-note is-small has-navy-soft-color has-text-color">yours to keep!</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Every guest goes home smiling</h2>
<!-- /wp:heading -->

<!-- wp:list {"className":"fact-list"} -->
<ul class="wp-block-list fact-list"><!-- wp:list-item -->
<li><strong>2 hrs</strong> minimum booking</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>12–15</strong> people an hour in black and white</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>8–10</strong> people an hour in colour</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>A4</strong> hand-drawn on paper, the original goes home with them</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40)"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/events/">How live drawing works</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
