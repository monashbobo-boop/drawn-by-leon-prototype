<?php
/**
 * Title: Custom portraits: title and intro
 * Slug: artist-portfolio/portraits-head
 * Categories: artist-sections, header
 * Description: Page title, tagline, two short paragraphs and the enquiry button on the left; two taped portraits on the right. Swap either picture in the editor.
 * Keywords: title, intro, portraits, photos, gift
 */
?>
<!-- wp:group {"align":"full","className":"portraits-head","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull portraits-head" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|70","top":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"54%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:54%"><!-- wp:paragraph {"className":"hand-note is-small","textColor":"navy-soft"} -->
<p class="hand-note is-small has-navy-soft-color has-text-color">from your photos, by hand</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"page-title","fontSize":"giant"} -->
<h1 class="wp-block-heading page-title has-giant-font-size">Custom portraits</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size"><strong>Familiar faces made into a personal gift</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Turn your favourite photos into a charming, hand-drawn caricature. I use gentle exaggeration to capture each person's features and personality while keeping them recognisable.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Whether it's a gift for someone special or a keepsake for yourself, a custom portrait adds a personal touch. Choose an A3 original on paper or a digital file, in black and white or colour. Clothing, a body, a background or a theme can also be included to make the portrait your own.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40)"><!-- wp:button {"backgroundColor":"yellow","textColor":"navy"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-navy-color has-yellow-background-color has-text-color has-background wp-element-button" href="/contact/#photo">Enquire About a Portrait</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"46%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:46%"><!-- wp:group {"className":"print-pair","layout":{"type":"default"}} -->
<div class="wp-block-group print-pair"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"is-style-taped"} -->
<figure class="wp-block-image size-large is-style-taped"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-05.webp' ); ?>" alt="Colour wedding portrait of a couple, with hearts and the words Forever love"/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"is-style-taped"} -->
<figure class="wp-block-image size-large is-style-taped"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-07.webp' ); ?>" alt="Colour portrait of a long-haired rider on his red motorbike, drawn from a photo"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
