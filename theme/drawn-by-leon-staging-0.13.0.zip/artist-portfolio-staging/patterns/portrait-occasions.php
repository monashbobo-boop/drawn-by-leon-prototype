<?php
/**
 * Title: Custom portraits: great for
 * Slug: artist-portfolio/portrait-occasions
 * Categories: artist-sections, services
 * Description: Five occasions for a portrait from photos, each with one of Leon's icons, a title and one line.
 * Keywords: occasions, gifts, birthday, wedding, family, retirement
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">A portrait for any occasion</h2>
<!-- /wp:heading -->

<!-- wp:group {"align":"wide","className":"type-grid is-five","style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide type-grid is-five" style="margin-top:var(--wp--preset--spacing--40)"><!-- wp:group {"className":"type-card","layout":{"type":"default"}} -->
<div class="wp-block-group type-card"><!-- wp:image {"lightbox":{"enabled":false},"width":"88px","sizeSlug":"full","className":"type-card__icon"} -->
<figure class="wp-block-image size-full is-resized type-card__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-birthday.webp' ); ?>" alt="" style="width:88px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Birthday gifts</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A thoughtful, personal gift for a friend or family member.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"type-card","layout":{"type":"default"}} -->
<div class="wp-block-group type-card"><!-- wp:image {"lightbox":{"enabled":false},"width":"88px","sizeSlug":"full","className":"type-card__icon"} -->
<figure class="wp-block-image size-full is-resized type-card__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-wedding.webp' ); ?>" alt="" style="width:88px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Weddings and anniversaries</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Celebrate a couple and a special moment in their lives.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"type-card","layout":{"type":"default"}} -->
<div class="wp-block-group type-card"><!-- wp:image {"lightbox":{"enabled":false},"width":"88px","sizeSlug":"full","className":"type-card__icon"} -->
<figure class="wp-block-image size-full is-resized type-card__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-photo-upload.webp' ); ?>" alt="" style="width:88px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Family keepsakes</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Bring your family together in one portrait to treasure.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"type-card","layout":{"type":"default"}} -->
<div class="wp-block-group type-card"><!-- wp:image {"lightbox":{"enabled":false},"width":"88px","sizeSlug":"full","className":"type-card__icon"} -->
<figure class="wp-block-image size-full is-resized type-card__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-gift.webp' ); ?>" alt="" style="width:88px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Retirement and thank-you gifts</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Show your appreciation for a colleague, teacher or someone who has made a difference.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"type-card","layout":{"type":"default"}} -->
<div class="wp-block-group type-card"><!-- wp:image {"lightbox":{"enabled":false},"width":"88px","sizeSlug":"full","className":"type-card__icon"} -->
<figure class="wp-block-image size-full is-resized type-card__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-photo.webp' ); ?>" alt="" style="width:88px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">A portrait for yourself</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>You don't need a special occasion to have your own caricature drawn.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
