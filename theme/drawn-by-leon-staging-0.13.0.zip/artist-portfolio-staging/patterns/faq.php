<?php
/**
 * Title: Live events: questions
 * Slug: artist-portfolio/faq
 * Categories: artist-sections, text
 * Description: Questions and answers about booking live caricatures. Each one opens on click (Details block).
 * Keywords: faq, questions, answers
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:group {"className":"faq-head","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between","verticalAlignment":"center"}} -->
<div class="wp-block-group faq-head"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Frequently asked questions</h2>
<!-- /wp:heading -->

<!-- wp:image {"lightbox":{"enabled":false},"width":"120px","sizeSlug":"full","className":"faq-icon"} -->
<figure class="wp-block-image size-full is-resized faq-icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-faq.webp' ); ?>" alt="" style="width:120px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:details {"className":"faq-item"} -->
<details class="wp-block-details faq-item"><summary>Should I choose black and white or colour?</summary><!-- wp:paragraph -->
<p>Black and white is quicker, making it a good option if you'd like more guests drawn within your booking time. Colour adds richness and detail but takes a little longer. I can help you choose based on your guest numbers and event plans.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"faq-item"} -->
<details class="wp-block-details faq-item"><summary>How long should I book for and can everyone be drawn?</summary><!-- wp:paragraph -->
<p>This depends on your guest numbers, whether you choose black and white or colour, and the length of your booking. As a guide, a two-hour booking allows for around 24-30 people in black and white or 16-20 in colour. Actual numbers can vary. If you'd like everyone to have a portrait, let me know your expected numbers and I'll help estimate the time needed.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"faq-item"} -->
<details class="wp-block-details faq-item"><summary>What space and equipment do I need to provide?</summary><!-- wp:paragraph -->
<p>Please provide a well-lit spot that's easy for guests to access, with room for seating and people to move around. I supply the paper and drawing materials. We'll confirm any tables, chairs or other setup requirements when you book. If you'd like your company logo or event details printed on the paper, let me know in advance so I can include the arrangements and additional cost in your quote.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"faq-item"} -->
<details class="wp-block-details faq-item"><summary>Can you draw at outdoor events?</summary><!-- wp:paragraph -->
<p>Yes, provided there's a sheltered spot with shade and protection from rain and wind. Let me know about your outdoor venue when enquiring so we can agree on the setup and a backup plan for poor weather.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"faq-item"} -->
<details class="wp-block-details faq-item"><summary>How far in advance should I book?</summary><!-- wp:paragraph -->
<p>Get in touch as soon as you have an event date so I can check availability. Short-notice enquiries are welcome too, and I'll let you know if I'm available.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"faq-item"} -->
<details class="wp-block-details faq-item"><summary>How do I get a quote?</summary><!-- wp:paragraph -->
<p>Send your event date, location, expected guest numbers, preferred booking length and whether you'd like black and white or colour. I'll provide a quote based on your event requirements.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"faq-item"} -->
<details class="wp-block-details faq-item"><summary>How do I confirm my booking and is a deposit required?</summary><!-- wp:paragraph -->
<p>Once we've confirmed availability, the service and your quote, I'll send the booking and payment details. Wedding bookings require a deposit to secure the date. Payment arrangements for other events will be explained with your quote. You'll receive the deposit amount, balance due date and cancellation or rescheduling terms before confirming your booking.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group -->
