<?php
/**
 * Title: Page: Home
 * Slug: artist-portfolio/page-home
 * Categories: artist-pages
 * Block Types: core/post-content
 * Post Types: page
 * Viewport Width: 1400
 * Description: Hero with face letters, services strip, two ways to get drawn, intro, recent drawings, reviews and the Your face here sketchpad at the end.
 */
?>
<!-- wp:pattern {"slug":"artist-portfolio/photo-hero"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/services-ticker"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/two-ways"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/intro-panel"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/gallery-preview"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/testimonials"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/face-here"} /-->
