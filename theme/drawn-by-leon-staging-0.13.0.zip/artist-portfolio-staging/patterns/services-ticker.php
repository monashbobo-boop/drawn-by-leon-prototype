<?php
/**
 * Title: Strip: services
 * Slug: artist-portfolio/services-ticker
 * Categories: artist-sections, banner
 * Description: A still strip of four services, each with one of Leon's hand-drawn icons, divided by thin rules like a ticket. Swap an icon by replacing its image; each label links to its page.
 * Keywords: services, strip, icons, banner
 */
?>
<!-- wp:group {"align":"full","className":"tag-strip","layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull tag-strip"><!-- wp:group {"align":"wide","className":"tag-strip__row","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide tag-strip__row"><!-- wp:group {"className":"tag-strip__item","layout":{"type":"default"}} -->
<div class="wp-block-group tag-strip__item"><!-- wp:image {"lightbox":{"enabled":false},"width":"64px","sizeSlug":"full","className":"tag-strip__icon"} -->
<figure class="wp-block-image size-full is-resized tag-strip__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-wedding.webp' ); ?>" alt="" style="width:64px"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"tag-strip__label"} -->
<p class="tag-strip__label"><a href="/events/">Weddings</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tag-strip__item","layout":{"type":"default"}} -->
<div class="wp-block-group tag-strip__item"><!-- wp:image {"lightbox":{"enabled":false},"width":"64px","sizeSlug":"full","className":"tag-strip__icon"} -->
<figure class="wp-block-image size-full is-resized tag-strip__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-birthday.webp' ); ?>" alt="" style="width:64px"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"tag-strip__label"} -->
<p class="tag-strip__label"><a href="/events/">Birthdays &amp; parties</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tag-strip__item","layout":{"type":"default"}} -->
<div class="wp-block-group tag-strip__item"><!-- wp:image {"lightbox":{"enabled":false},"width":"64px","sizeSlug":"full","className":"tag-strip__icon"} -->
<figure class="wp-block-image size-full is-resized tag-strip__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-community.webp' ); ?>" alt="" style="width:64px"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"tag-strip__label"} -->
<p class="tag-strip__label"><a href="/events/">Corporate &amp; community</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tag-strip__item","layout":{"type":"default"}} -->
<div class="wp-block-group tag-strip__item"><!-- wp:image {"lightbox":{"enabled":false},"width":"64px","sizeSlug":"full","className":"tag-strip__icon"} -->
<figure class="wp-block-image size-full is-resized tag-strip__icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-photo.webp' ); ?>" alt="" style="width:64px"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"tag-strip__label"} -->
<p class="tag-strip__label"><a href="/custom-portraits/">Portraits from photos</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
