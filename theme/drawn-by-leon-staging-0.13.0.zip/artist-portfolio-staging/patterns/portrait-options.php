<?php
/**
 * Title: Custom portraits: custom options
 * Slug: artist-portfolio/portrait-options
 * Categories: artist-sections, services
 * Description: Three options, each with an example drawing, a title and a short paragraph. Swap any picture in the editor.
 * Keywords: options, custom, colour, black and white, family, theme
 */
?>
<!-- wp:group {"align":"full","className":"is-style-panel","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull is-style-panel" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Your portrait options</h2>
<!-- /wp:heading -->

<!-- wp:columns {"align":"wide","className":"option-cards","style":{"spacing":{"margin":{"top":"var:preset|spacing|50"},"blockGap":{"left":"var:preset|spacing|50","top":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide option-cards" style="margin-top:var(--wp--preset--spacing--50)"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"option-card__art"} -->
<figure class="wp-block-image size-large option-card__art"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-13.webp' ); ?>" alt="Colour portrait of three friends raising their coffee cups"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"fontSize":"x-large"} -->
<h3 class="wp-block-heading has-x-large-font-size">Individuals, couples and families</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Choose a portrait of one person, or bring partners, friends or family members together in the same artwork.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"option-card__art"} -->
<figure class="wp-block-image size-large option-card__art"><img src="<?php echo artist_portfolio_image( 'works/live-bw/live-bw-01.webp' ); ?>" alt="Black and white portrait of a family of five"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"fontSize":"x-large"} -->
<h3 class="wp-block-heading has-x-large-font-size">Black and white or colour</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Black and white gives a clean, expressive finish. Colour adds warmth and detail. Choose the option you prefer.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"option-card__art"} -->
<figure class="wp-block-image size-large option-card__art"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-15.webp' ); ?>" alt="Colour 70th birthday portrait of three family members around a cake"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"fontSize":"x-large"} -->
<h3 class="wp-block-heading has-x-large-font-size">Personal touches</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>You can request particular clothing or add a body, background or theme. Bodies, backgrounds and themes are charged separately. Each added element costs the same as adding one person to the portrait. The details and total price will be confirmed in your quote.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
