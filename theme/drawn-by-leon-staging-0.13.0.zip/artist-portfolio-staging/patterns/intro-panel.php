<?php
/**
 * Title: Intro panel: hi, I'm Leon
 * Slug: artist-portfolio/intro-panel
 * Categories: artist-sections, about
 * Description: Blue panel with Leon's character popping out of the top edge and a short introduction.
 * Keywords: about, intro, panel, artist, mascot
 */
?>
<!-- wp:group {"align":"full","className":"is-style-panel has-mascot","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1100px"}} -->
<div class="wp-block-group alignfull is-style-panel has-mascot" style="margin-top:var(--wp--preset--spacing--70);padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"bottom","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60","top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns are-vertically-aligned-bottom"><!-- wp:column {"verticalAlignment":"bottom","width":"36%"} -->
<div class="wp-block-column is-vertically-aligned-bottom" style="flex-basis:36%"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full","className":"mascot-pop"} -->
<figure class="wp-block-image size-full mascot-pop"><img src="<?php echo artist_portfolio_image( 'brand/leon-mascot.webp' ); ?>" alt="Leon's self-caricature, holding a marker and giving a thumbs up"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"64%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:64%"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Who's holding the pen?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Hi, I'm Leon. I was an art teacher for over ten years, and now I draw live caricatures and custom portraits from photos.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>My style is detailed and charming, with gentle exaggeration that keeps everyone recognisable. Every drawing is done by hand, in black and white or colour. I'm based in Melbourne.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40)"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/about/">More about me</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
