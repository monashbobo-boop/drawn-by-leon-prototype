<?php
/**
 * Title: Page: Contact
 * Slug: artist-portfolio/page-contact
 * Categories: artist-pages
 * Block Types: core/post-content
 * Post Types: page
 * Viewport Width: 1400
 * Description: Say hi title, switch between event and photo forms, side note.
 */
?>
<!-- wp:pattern {"slug":"artist-portfolio/enquiry-form"} /-->
