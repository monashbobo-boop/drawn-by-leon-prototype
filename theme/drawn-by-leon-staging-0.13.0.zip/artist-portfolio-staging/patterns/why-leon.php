<?php
/**
 * Title: Live events: why choose Leon
 * Slug: artist-portfolio/why-leon
 * Categories: artist-sections, about
 * Description: Leon's character holding his CARICATURES sign next to a short paragraph on why to book him.
 * Keywords: why, about, trust, mascot
 */
?>
<!-- wp:group {"align":"full","className":"why-leon","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"backgroundColor":"yellow-soft","layout":{"type":"constrained","contentSize":"1100px"}} -->
<div class="wp-block-group alignfull why-leon has-yellow-soft-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60","top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"30%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:30%"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full","className":"why-leon__mascot"} -->
<figure class="wp-block-image size-full why-leon__mascot"><img src="<?php echo artist_portfolio_image( 'brand/mascot-sign.webp' ); ?>" alt="Leon's cartoon self holding a yellow CARICATURES sign"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"70%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:70%"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Why choose Leon</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">I bring experience drawing at weddings, large festivals and community events, along with a friendly approach that helps guests feel at ease.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Before your event, we'll discuss the timing, space and drawing preferences so everything is ready for the day.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
