<?php
/**
 * Title: Portfolio: page header
 * Slug: artist-portfolio/portfolio-head
 * Categories: artist-sections, header
 * Description: Giant title with an outlined number, and a line of intro. Change the number in the title as the collection grows.
 * Keywords: portfolio, header, title
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|20"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--20)"><!-- wp:heading {"level":1,"className":"title-outline","fontSize":"giant"} -->
<h1 class="wp-block-heading title-outline has-giant-font-size"><mark style="background-color:rgba(0, 0, 0, 0)" class="has-inline-color">50+</mark> faces, one pen</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large","style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<p class="has-large-font-size" style="margin-top:var(--wp--preset--spacing--40)">Drawn live at weddings, parties and markets, or at my desk from your photos. Pick a style below and tap a drawing to see it bigger.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

