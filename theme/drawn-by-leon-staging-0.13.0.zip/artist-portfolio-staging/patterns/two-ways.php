<?php
/**
 * Title: Two ways to get drawn
 * Slug: artist-portfolio/two-ways
 * Categories: artist-sections, services
 * Description: Two big colour cards, edge to edge: live at events (one photo) and drawn from photos (a Gallery with the "Collage" style, five drawings that grow a little under the pointer). Each card has a title with its Explore more button on the same line, a short intro and one line of key facts.
 * Keywords: services, live, events, photos, portraits, two ways
 */
?>
<!-- wp:group {"align":"full","className":"two-ways","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull two-ways" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:paragraph {"className":"hand-note is-small","style":{"typography":{"textAlign":"center"}},"textColor":"navy-soft"} -->
<p class="has-text-align-center hand-note is-small has-navy-soft-color has-text-color">pick the one that suits you</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"style":{"typography":{"textAlign":"center"}},"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-text-align-center has-xx-large-font-size">Two ways to get drawn</h2>
<!-- /wp:heading -->

<!-- wp:columns {"align":"full","className":"two-ways__grid"} -->
<div class="wp-block-columns alignfull two-ways__grid"><!-- wp:column {"className":"two-ways__card","backgroundColor":"yellow","textColor":"navy"} -->
<div class="wp-block-column two-ways__card has-navy-color has-yellow-background-color has-text-color has-background"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"two-ways__media"} -->
<figure class="wp-block-image size-large two-ways__media"><img src="<?php echo artist_portfolio_image( 'photos/event-birthday.webp' ); ?>" alt="Leon drawing a child at a birthday party while the other kids watch"/></figure>
<!-- /wp:image -->

<!-- wp:group {"className":"two-ways__head","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between","verticalAlignment":"center"}} -->
<div class="wp-block-group two-ways__head"><!-- wp:heading {"level":3,"className":"two-ways__title"} -->
<h3 class="wp-block-heading two-ways__title">Live at events</h3>
<!-- /wp:heading -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/events/">Explore more</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"two-ways__text"} -->
<p class="two-ways__text">I draw your guests on the spot at weddings, parties, work and community events. They sit, laugh, watch it come together and take the original home.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"two-ways__facts"} -->
<p class="two-ways__facts">A4 on paper · Black &amp; white or colour · From 2 hours</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"two-ways__card","backgroundColor":"navy","textColor":"white"} -->
<div class="wp-block-column two-ways__card has-white-color has-navy-background-color has-text-color has-background"><!-- wp:gallery {"linkTo":"none","imageCrop":false,"className":"is-style-collage two-ways__media"} -->
<figure class="wp-block-gallery has-nested-images columns-default is-style-collage two-ways__media"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-02.webp' ); ?>" alt="Colour caricature of a woman hugging her dog"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-13.webp' ); ?>" alt="Colour caricature of three mates holding drinks"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-12.webp' ); ?>" alt="Colour caricature of a man with his dog"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-17.webp' ); ?>" alt="Colour caricature of a boy holding his cat"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-09.webp' ); ?>" alt="Colour caricature of a man riding a motorbike at Red Rock"/></figure>
<!-- /wp:image --></figure>
<!-- /wp:gallery -->

<!-- wp:group {"className":"two-ways__head","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between","verticalAlignment":"center"}} -->
<div class="wp-block-group two-ways__head"><!-- wp:heading {"level":3,"className":"two-ways__title"} -->
<h3 class="wp-block-heading two-ways__title">Drawn from photos</h3>
<!-- /wp:heading -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/custom-portraits/">Explore more</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"two-ways__text"} -->
<p class="two-ways__text">Send me your favourite photos and I&#8217;ll turn them into a hand-drawn caricature. A personal gift for birthdays, weddings and anniversaries, or just for you.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"two-ways__facts"} -->
<p class="two-ways__facts">A3 original or digital file · Black &amp; white or colour · Ready in about 5 business days</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
