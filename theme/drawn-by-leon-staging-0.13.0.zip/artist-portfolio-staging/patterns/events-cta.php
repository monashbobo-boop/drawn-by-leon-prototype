<?php
/**
 * Title: Live events: how booking works
 * Slug: artist-portfolio/events-cta
 * Categories: artist-sections, call-to-action
 * Description: Yellow closing band that runs into the footer wave. Heading, one line and the Check my date button on the left; on the right a white card with the three booking steps (a List block with the "Steps" style: edit the items like any list).
 * Keywords: cta, book, enquire, quote, steps
 */
?>
<!-- wp:group {"align":"full","className":"cta-band cta-plan","style":{"spacing":{"padding":{"top":"var:preset|spacing|70"}}},"backgroundColor":"yellow","textColor":"navy","layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull cta-band cta-plan has-navy-color has-yellow-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60","top":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Make your event one to remember</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Planning a wedding, party or work event? Tell me what you have in mind and we&#8217;ll arrange a live drawing experience to suit your occasion.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40)"><!-- wp:button {"backgroundColor":"navy","textColor":"white"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-white-color has-navy-background-color has-text-color has-background wp-element-button" href="/contact/#event">Check my date</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%"><!-- wp:group {"className":"is-style-card plan-card","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card plan-card"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">How booking works</p>
<!-- /wp:paragraph -->

<!-- wp:list {"ordered":true,"className":"is-style-steps"} -->
<ol class="wp-block-list is-style-steps"><!-- wp:list-item -->
<li><strong>Send your date and venue.</strong> Add a rough guest count and whether you&#8217;d like black and white or colour.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Get your quote.</strong> I&#8217;ll reply by email with my availability and a price.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Lock it in.</strong> On the day I bring the markers and paper and draw your guests.</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
