<?php
/**
 * Title: About Leon
 * Slug: artist-portfolio/about-intro
 * Categories: artist-sections, about
 * Description: Leon's character next to his story and drawing style. Replace the story with Leon's own words; a photo of Leon drawing can go in place of the character.
 * Keywords: about, artist, bio, story
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|70","top":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"38%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:38%"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full","className":"sticker-single"} -->
<figure class="wp-block-image size-full sticker-single"><img src="<?php echo artist_portfolio_image( 'brand/leon-mascot.webp' ); ?>" alt="Leon's self-caricature, holding a marker and giving a thumbs up"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"62%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:62%"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Cute, and clearly you</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">I want every drawing to make people say "that's so cute, and it's definitely me". Detailed, charming, and true to the person in front of me.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Every drawing starts the same way: a quick look, a big smile and a marker. I draw by hand on paper, in black and white or full colour, and my favourite part is the moment people see themselves on the page and burst out laughing.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Live caricatures are drawn by hand on A4 paper, and portraits from photos on A3 paper or as a digital file, in black and white or colour. I'm based in Melbourne.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
