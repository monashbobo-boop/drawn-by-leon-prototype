<?php
/**
 * Title: Page: Privacy & copyright
 * Slug: artist-portfolio/page-privacy
 * Categories: artist-pages
 * Block Types: core/post-content
 * Post Types: page
 * Description: Plain-English privacy notice and copyright terms in one narrow column. Change the "Last updated" date whenever the text changes.
 * Keywords: privacy, policy, copyright, legal, terms
 */
?>
<!-- wp:group {"align":"full","className":"legal-page","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull legal-page" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:heading {"level":1,"className":"page-title","fontSize":"xx-large"} -->
<h1 class="wp-block-heading page-title has-xx-large-font-size">Privacy &amp; copyright</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">This page explains what happens to the details and photos you send to Drawn by Leon, and who owns the drawings.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">Last updated: 28 October 2026</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">Your details</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>When you send a booking or portrait enquiry, I receive what you type into the form: your name, email address, phone number if you add it, the details of your event or portrait, and any photos you upload.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>I use them only to reply to you, prepare a quote, plan your event and draw your portrait. I don&#8217;t sell your details or share them with anyone for marketing.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">Your photos</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Photos you send are used as reference for your drawing and nothing else. I only share a finished drawing, or a photo of you holding it, on this website or on Instagram and Facebook with your permission.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Ask any time and I&#8217;ll delete the photos you sent.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">Where it&#8217;s kept</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>This website runs on WordPress.com. Form messages and uploaded photos are stored with WordPress.com and in my email inbox.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Visits to the site are counted with Jetpack Stats and Google Analytics. They use cookies to see how many people visit and which pages are popular; they don&#8217;t tell me who you are. You can block these cookies in your browser settings.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">Your choices</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Email <a href="mailto:leon.caricature@gmail.com">leon.caricature@gmail.com</a> to see, correct or delete the details I hold about you.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">Copyright</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>All drawings, illustrations and photos on this site are &copy; Drawn by Leon unless noted otherwise. Please don&#8217;t copy, print or reuse them without permission.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>When you buy a caricature, the original drawing or file is yours to keep, frame, give as a gift and share on your own social media. Copyright in the drawing stays with Leon, so please ask first before using it on products, logos, advertising or anything sold.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">Contact</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Drawn by Leon, Melbourne VIC<br><a href="mailto:leon.caricature@gmail.com">leon.caricature@gmail.com</a><br><a href="tel:+61466532313">0466 532 313</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
