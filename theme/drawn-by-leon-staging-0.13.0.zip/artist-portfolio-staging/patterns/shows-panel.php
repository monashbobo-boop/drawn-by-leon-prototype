<?php
/**
 * Title: About: shows I've drawn at
 * Slug: artist-portfolio/shows-panel
 * Categories: artist-sections, about
 * Description: Photos from shows, markets and festivals Leon has drawn at, each with the event name and place. Placeholder names: replace "Event name" and "Place, year", and swap the photos.
 * Keywords: shows, festivals, experience
 */
?>
<!-- wp:group {"align":"full","className":"cta-band shows-band","style":{"spacing":{"padding":{"top":"var:preset|spacing|70"}}},"backgroundColor":"yellow","textColor":"navy","layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull cta-band shows-band has-navy-color has-yellow-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--70)"><!-- wp:paragraph {"className":"hand-note","textColor":"navy"} -->
<p class="hand-note has-navy-color has-text-color">Leon has drawn at</p>
<!-- /wp:paragraph -->

<!-- wp:group {"align":"wide","className":"shows-grid","style":{"spacing":{"margin":{"top":"var:preset|spacing|50"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide shows-grid" style="margin-top:var(--wp--preset--spacing--50)"><!-- wp:group {"className":"show-item","layout":{"type":"default"}} -->
<div class="wp-block-group show-item"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"show-item__photo"} -->
<figure class="wp-block-image size-large show-item__photo"><img src="<?php echo artist_portfolio_image( 'photos/guests-show-2.webp' ); ?>" alt="A couple at Leon's stall holding up their black and white caricature"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"fontSize":"x-large"} -->
<h3 class="wp-block-heading has-x-large-font-size">Event name</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">Place, year</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"show-item","layout":{"type":"default"}} -->
<div class="wp-block-group show-item"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"show-item__photo"} -->
<figure class="wp-block-image size-large show-item__photo"><img src="<?php echo artist_portfolio_image( 'photos/guests-festival-1.webp' ); ?>" alt="A couple at an outdoor festival holding up their colour caricature"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"fontSize":"x-large"} -->
<h3 class="wp-block-heading has-x-large-font-size">Event name</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">Place, year</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"show-item","layout":{"type":"default"}} -->
<div class="wp-block-group show-item"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"show-item__photo"} -->
<figure class="wp-block-image size-large show-item__photo"><img src="<?php echo artist_portfolio_image( 'photos/guests-show-1.webp' ); ?>" alt="A couple in front of Leon's banner holding up their caricature"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"fontSize":"x-large"} -->
<h3 class="wp-block-heading has-x-large-font-size">Event name</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">Place, year</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"show-item","layout":{"type":"default"}} -->
<div class="wp-block-group show-item"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"show-item__photo"} -->
<figure class="wp-block-image size-large show-item__photo"><img src="<?php echo artist_portfolio_image( 'photos/guests-market-1.webp' ); ?>" alt="A couple at an indoor market holding up their colour caricature"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"fontSize":"x-large"} -->
<h3 class="wp-block-heading has-x-large-font-size">Event name</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">Place, year</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
