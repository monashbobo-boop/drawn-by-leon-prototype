<?php
/**
 * Title: Services menu: big list
 * Slug: artist-portfolio/service-menu
 * Categories: artist-sections, services
 * Description: Giant typographic list of the two services, each with an icon and one line. Rows light up yellow on hover.
 * Keywords: services, menu, list, icons
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:paragraph {"align":"right","className":"hand-note","textColor":"navy-soft"} -->
<p class="has-text-align-right hand-note has-navy-soft-color has-text-color">two ways to get drawn!</p>
<!-- /wp:paragraph -->

<!-- wp:group {"align":"wide","className":"service-menu","style":{"spacing":{"blockGap":"0"}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide service-menu">
<!-- wp:group {"className":"service-row","style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group service-row"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-live-portrait.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><a href="/events/">Live at your event</a></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Detailed, charming caricatures drawn on the spot at weddings, parties, corporate and community events. Guests watch their portrait come together and take the original home.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"service-row","style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group service-row"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-photo.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><a href="/custom-portraits/">Drawn from your photo</a></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A hand-drawn A3 or digital portrait from the photos you send. A gift for birthdays, anniversaries, families and retirements, or just for you.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
</div>
<!-- /wp:group --></div>
<!-- /wp:group -->
