<?php
/**
 * Title: Custom portraits: what to send me
 * Slug: artist-portfolio/portraits-cta
 * Categories: artist-sections, call-to-action
 * Description: Closing section that runs into the footer wave. A taped drawing on the left; on the right the heading, one line, a "What to send me" checklist (a List block with the "Ticks" style) and the Start my portrait button.
 * Keywords: cta, portrait, gift, enquire, checklist
 */
?>
<!-- wp:group {"align":"full","className":"cta-band cta-gift","style":{"spacing":{"padding":{"top":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull cta-band cta-gift" style="padding-top:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60","top":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"40%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:40%"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"is-style-taped"} -->
<figure class="wp-block-image size-large is-style-taped"><img src="<?php echo artist_portfolio_image( 'works/from-photos/from-photos-08.webp' ); ?>" alt="Hand-drawn colour caricature portrait of a bride and groom, drawn from a photo"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"60%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:60%"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Give a gift with a personal story</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Send your photos and ideas, and let&#8217;s turn a familiar face or a special memory into a portrait to treasure.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">What to send me</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"is-style-ticks"} -->
<ul class="wp-block-list is-style-ticks"><!-- wp:list-item -->
<li>A clear, well-lit photo of each face</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Any outfit, pet, background or theme ideas</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>The date you&#8217;d like it by</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40)"><!-- wp:button {"backgroundColor":"navy","textColor":"white"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-white-color has-navy-background-color has-text-color has-background wp-element-button" href="/contact/#photo">Start my portrait</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
