<?php
/**
 * Title: Custom portraits: questions
 * Slug: artist-portfolio/portrait-faq
 * Categories: artist-sections, text
 * Description: Questions and answers about portraits from photos. Each one opens on click (Details block).
 * Keywords: faq, questions, photos, delivery
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:group {"className":"faq-head","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between","verticalAlignment":"center"}} -->
<div class="wp-block-group faq-head"><!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Frequently asked questions</h2>
<!-- /wp:heading -->

<!-- wp:image {"lightbox":{"enabled":false},"width":"120px","sizeSlug":"full","className":"faq-icon"} -->
<figure class="wp-block-image size-full is-resized faq-icon"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-faq.webp' ); ?>" alt="" style="width:120px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:details {"className":"faq-item"} -->
<details class="wp-block-details faq-item"><summary>What kind of photos should I send?</summary><!-- wp:paragraph -->
<p>Please send clear, well-lit photos that show each person's facial features. Avoid heavy filters, blurry images or anything that covers the face. A few photos from different angles can help me understand the person's features. If you'd like particular clothing included, please send reference images too.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"faq-item"} -->
<details class="wp-block-details faq-item"><summary>Do I need a group photo for a portrait of several people?</summary><!-- wp:paragraph -->
<p>No. You can send separate, clear photos of each person and let me know who you'd like included. I'll arrange them together in the portrait.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"faq-item"} -->
<details class="wp-block-details faq-item"><summary>Can you include particular clothing, a background or a theme?</summary><!-- wp:paragraph -->
<p>Yes. This could be a meaningful outfit, something related to the person's work or a favourite hobby. Tell me your ideas and include reference images when you enquire. Adding a body, background or theme costs extra, with each element charged at the same rate as one additional person. All costs will be confirmed in your quote.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"faq-item"} -->
<details class="wp-block-details faq-item"><summary>When will I receive my portrait?</summary><!-- wp:paragraph -->
<p>Portraits are usually completed within five business days once your photos, requirements and payment are confirmed. Allow extra time for postage if you choose an original on paper. Digital files are sent by email once complete.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"faq-item"} -->
<details class="wp-block-details faq-item"><summary>Can you accept urgent orders?</summary><!-- wp:paragraph -->
<p>If you need a portrait for a birthday, wedding or another important date, let me know when enquiring. I'll check my current orders and confirm whether I can meet your deadline before you order.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"faq-item"} -->
<details class="wp-block-details faq-item"><summary>What is the difference between the paper original and a digital file?</summary><!-- wp:paragraph -->
<p>The paper option is an original A3 artwork that you can frame and keep. A digital file is delivered by email, making it easy to save, share or arrange your own printing. Please let me know which format you'd prefer when enquiring.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"faq-item"} -->
<details class="wp-block-details faq-item"><summary>How do I get a quote?</summary><!-- wp:paragraph -->
<p>Tell me how many people you'd like drawn, whether you prefer black and white or colour, your preferred format and any requests for a body, background or theme. If you'd like an original posted, include your delivery suburb or postcode so I can confirm the total cost.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group -->
