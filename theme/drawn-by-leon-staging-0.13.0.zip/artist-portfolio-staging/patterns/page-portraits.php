<?php
/**
 * Title: Page: Custom portraits
 * Slug: artist-portfolio/page-portraits
 * Categories: artist-pages
 * Block Types: core/post-content
 * Post Types: page
 * Viewport Width: 1400
 * Description: Portraits from photos: title and intro, occasions, custom options, service details, how to order, recent portraits, FAQ and closing band.
 */
?>
<!-- wp:pattern {"slug":"artist-portfolio/portraits-head"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/portrait-occasions"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/portrait-options"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/portrait-details"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/portrait-steps"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/portrait-gallery"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/portrait-faq"} /-->

<!-- wp:pattern {"slug":"artist-portfolio/portraits-cta"} /-->
