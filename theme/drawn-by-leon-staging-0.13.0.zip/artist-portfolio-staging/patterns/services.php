<?php
/**
 * Title: Services: event types
 * Slug: artist-portfolio/services
 * Categories: artist-sections, services
 * Description: Numbered rows for weddings, private parties, and corporate and community events. Duplicate a row to add another type.
 * Keywords: services, events, weddings, corporate, parties, community
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">What I draw at</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size">Book me for</h2>
<!-- /wp:heading -->

<!-- wp:group {"align":"wide","className":"numbered-rows","style":{"spacing":{"margin":{"top":"var:preset|spacing|50"},"blockGap":"0"}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide numbered-rows" style="margin-top:var(--wp--preset--spacing--50)"><!-- wp:columns {"className":"numbered-row","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50","top":"var:preset|spacing|20"}}}} -->
<div class="wp-block-columns numbered-row"><!-- wp:column {"width":"10%"} -->
<div class="wp-block-column" style="flex-basis:10%"><!-- wp:paragraph {"className":"row-number"} -->
<p class="row-number">01</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"45%"} -->
<div class="wp-block-column" style="flex-basis:45%"><!-- wp:heading {"level":3,"fontSize":"x-large"} -->
<h3 class="wp-block-heading has-x-large-font-size">Weddings</h3>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"45%"} -->
<div class="wp-block-column" style="flex-basis:45%"><!-- wp:paragraph -->
<p>Something fun for guests between the ceremony and dinner. Everyone takes home a drawing, and you get a few to keep for the album.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"className":"numbered-row","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50","top":"var:preset|spacing|20"}}}} -->
<div class="wp-block-columns numbered-row"><!-- wp:column {"width":"10%"} -->
<div class="wp-block-column" style="flex-basis:10%"><!-- wp:paragraph {"className":"row-number"} -->
<p class="row-number">02</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"45%"} -->
<div class="wp-block-column" style="flex-basis:45%"><!-- wp:heading {"level":3,"fontSize":"x-large"} -->
<h3 class="wp-block-heading has-x-large-font-size">Private parties</h3>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"45%"} -->
<div class="wp-block-column" style="flex-basis:45%"><!-- wp:paragraph -->
<p>Birthdays, engagements and family celebrations. A crowd always gathers to watch, so the drawing table turns into the fun corner of the room.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"className":"numbered-row","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50","top":"var:preset|spacing|20"}}}} -->
<div class="wp-block-columns numbered-row"><!-- wp:column {"width":"10%"} -->
<div class="wp-block-column" style="flex-basis:10%"><!-- wp:paragraph {"className":"row-number"} -->
<p class="row-number">03</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"45%"} -->
<div class="wp-block-column" style="flex-basis:45%"><!-- wp:heading {"level":3,"fontSize":"x-large"} -->
<h3 class="wp-block-heading has-x-large-font-size">Corporate &amp; community</h3>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"45%"} -->
<div class="wp-block-column" style="flex-basis:45%"><!-- wp:paragraph -->
<p>Work parties, trade shows, festivals and community days. An easy way to get people talking, and something to remember the day by.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
