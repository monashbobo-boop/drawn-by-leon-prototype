<?php
/**
 * Title: Hero: photos, face letters and title
 * Slug: artist-portfolio/photo-hero
 * Categories: artist-sections, banner
 * Description: Full-width hero. Behind the text, a Gallery with the "Crossfade" style fades from one photo to the next (add, remove or reorder its pictures). Under "hi, I'm Leon!" the word CARICATURES is a Gallery with the "Face letters" style: one picture per letter, a few of them come alive now and then. The round Book Leon sticker sits in the corner.
 * Keywords: hero, cover, photo, banner, home, title, caricatures
 */
?>
<!-- wp:cover {"url":"<?php echo artist_portfolio_image( 'photos/hero-frame-1.webp' ); ?>","alt":"","dimRatio":100,"customGradient":"linear-gradient(90deg,rgba(18,65,138,0.95) 0%,rgba(18,65,138,0.82) 30%,rgba(18,65,138,0.3) 52%,rgba(18,65,138,0) 64%)","focalPoint":{"x":0.37,"y":0.3},"minHeight":82,"minHeightUnit":"vh","contentPosition":"center left","isDark":true,"align":"full","className":"photo-hero","layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-cover alignfull is-dark has-custom-content-position is-position-center-left photo-hero" style="min-height:82vh"><img class="wp-block-cover__image-background" alt="" src="<?php echo artist_portfolio_image( 'photos/hero-frame-1.webp' ); ?>" style="object-position:37% 30%" data-object-fit="cover" data-object-position="37% 30%"/><span aria-hidden="true" class="wp-block-cover__background has-background-dim-100 has-background-dim wp-block-cover__gradient-background has-background-gradient" style="background:linear-gradient(90deg,rgba(18,65,138,0.95) 0%,rgba(18,65,138,0.82) 30%,rgba(18,65,138,0.3) 52%,rgba(18,65,138,0) 64%)"></span><div class="wp-block-cover__inner-container"><!-- wp:gallery {"linkTo":"none","className":"is-style-crossfade hero-fade"} -->
<figure class="wp-block-gallery has-nested-images columns-default is-cropped is-style-crossfade hero-fade"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'photos/hero-frame-1.webp' ); ?>" alt="Guests at markets and festivals holding up the caricatures Leon just drew of them"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'photos/hero-frame-2.webp' ); ?>" alt="Happy guests with their caricatures at Leon's stall"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo artist_portfolio_image( 'photos/hero-frame-3.webp' ); ?>" alt="Couples and friends showing off their caricatures"/></figure>
<!-- /wp:image --></figure>
<!-- /wp:gallery -->

<!-- wp:image {"lightbox":{"enabled":false},"width":"160px","sizeSlug":"full","linkDestination":"custom","className":"photo-hero__badge"} -->
<figure class="wp-block-image size-full is-resized photo-hero__badge"><a href="/contact/"><img src="<?php echo artist_portfolio_image( 'brand/drawn-by-leon-round.webp' ); ?>" alt="Drawn by Leon, live caricatures" style="width:160px"/></a></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"hand-note is-small","textColor":"yellow"} -->
<p class="hand-note is-small has-yellow-color has-text-color">hi, I'm Leon!</p>
<!-- /wp:paragraph -->

<!-- wp:gallery {"linkTo":"none","imageCrop":false,"className":"is-style-face-letters"} -->
<figure class="wp-block-gallery has-nested-images columns-default is-style-face-letters"><!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_image( 'letters/letter-01-c1.webp' ); ?>" alt="Caricatures"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_image( 'letters/letter-02-a1.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_image( 'letters/letter-03-r1.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_image( 'letters/letter-04-i.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_image( 'letters/letter-05-c2.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_image( 'letters/letter-06-a2.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_image( 'letters/letter-07-t.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_image( 'letters/letter-08-u.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_image( 'letters/letter-09-r2.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_image( 'letters/letter-10-e.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_image( 'letters/letter-11-s.webp' ); ?>" alt=""/></figure>
<!-- /wp:image --></figure>
<!-- /wp:gallery -->

<!-- wp:heading {"level":1,"className":"photo-hero__title","textColor":"white","fontSize":"giant"} -->
<h1 class="wp-block-heading photo-hero__title has-white-color has-text-color has-giant-font-size">Fun faces.<br>Happy memories.</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"photo-hero__lead","textColor":"white","fontSize":"large"} -->
<p class="photo-hero__lead has-white-color has-text-color has-large-font-size">Charming caricatures, drawn live at weddings, parties and events around Melbourne, or from your favourite photo.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover -->
