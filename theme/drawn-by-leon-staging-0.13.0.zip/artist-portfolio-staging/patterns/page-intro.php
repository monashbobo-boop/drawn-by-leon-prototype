<?php
/**
 * Title: Page intro
 * Slug: artist-portfolio/page-intro
 * Categories: artist-sections, header
 * Description: Small numbered label, giant page title and one line of intro, with plenty of white space. Use at the top of inner pages.
 * Keywords: title, intro, header, banner
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">01 / Section</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"align":"wide","fontSize":"giant"} -->
<h1 class="wp-block-heading alignwide has-giant-font-size">Page title</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large","style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<p class="has-large-font-size" style="margin-top:var(--wp--preset--spacing--40)">One or two sentences that tell visitors what this page is about.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
