<?php
/**
 * Title: Contact: postcard to Leon
 * Slug: artist-portfolio/enquiry-form
 * Categories: artist-sections, contact
 * Description: "Book Leon" title, three picture cards that switch between the event form, the photo form (with an optional photo upload) and a short question form, and the form itself laid out like a postcard (writing side and address side with a stamp). At the bottom, doodles drop into a pile when the area scrolls into view (add or remove images in the "doodle-drop" group). Set the recipient email in each form's settings.
 * Keywords: contact, form, enquiry, booking, quote, photo, postcard
 */
?>
<!-- wp:group {"align":"full","className":"contact-page","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|40"}}},"layout":{"type":"constrained","contentSize":"1180px"}} -->
<div class="wp-block-group alignfull contact-page" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--40)"><!-- wp:columns {"verticalAlignment":"bottom","align":"wide","className":"contact-head","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60","top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-bottom contact-head"><!-- wp:column {"verticalAlignment":"bottom","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-bottom" style="flex-basis:50%"><!-- wp:paragraph {"className":"hand-note is-small","textColor":"navy-soft"} -->
<p class="hand-note is-small has-navy-soft-color has-text-color">drop me a line</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"page-title","fontSize":"giant"} -->
<h1 class="wp-block-heading page-title has-giant-font-size">Book Leon</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Pick a card, fill in the postcard, and I'll write back by email with a quote.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"bottom","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-bottom" style="flex-basis:50%"><!-- wp:paragraph {"className":"hand-note is-small pick-note","textColor":"red"} -->
<p class="hand-note is-small pick-note has-red-color has-text-color">pick one</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"form-switch"} -->
<div class="wp-block-buttons form-switch"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#event">Live at my event</a></div>
<!-- /wp:button -->

<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#photo">Drawn from my photo</a></div>
<!-- /wp:button -->

<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#other">Something else</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"align":"wide","className":"postcard","style":{"spacing":{"margin":{"top":"var:preset|spacing|50"},"blockGap":{"left":"0","top":"0"}}}} -->
<div class="wp-block-columns alignwide postcard" style="margin-top:var(--wp--preset--spacing--50)"><!-- wp:column {"width":"64%","className":"postcard__write"} -->
<div class="wp-block-column postcard__write" style="flex-basis:64%"><!-- wp:group {"anchor":"event","className":"form-block","layout":{"type":"default"}} -->
<div id="event" class="wp-block-group form-block"><!-- wp:paragraph {"className":"hand-note postcard__dear","textColor":"navy"} -->
<p class="hand-note postcard__dear has-navy-color has-text-color">Dear Leon, can you draw at my event?</p>
<!-- /wp:paragraph -->

<!-- wp:jetpack/contact-form {"subject":"New event enquiry from the website"} -->
<div class="wp-block-jetpack-contact-form"><!-- wp:jetpack/field-name {"label":"Your name","required":true,"width":50} /-->

<!-- wp:jetpack/field-email {"label":"Email","required":true,"width":50} /-->

<!-- wp:jetpack/field-select {"label":"Type of event","required":true,"options":["Wedding","Birthday or private party","Corporate event","Festival or community event","Something else (surprise me!)"],"width":50} /-->

<!-- wp:jetpack/field-date {"label":"Event date","required":true,"width":50} /-->

<!-- wp:jetpack/field-text {"label":"Location (suburb or venue)","required":true,"width":50} /-->

<!-- wp:jetpack/field-text {"label":"Expected number of guests","required":true,"width":50} /-->

<!-- wp:jetpack/field-select {"label":"How long would you like me to draw?","options":["2 hours","3 hours","4 hours","5 hours","6 hours","Not sure yet"],"width":50} /-->

<!-- wp:jetpack/field-select {"label":"Black and white or colour?","options":["Black and white","Colour","Not sure yet"],"width":50} /-->

<!-- wp:jetpack/field-telephone {"label":"Phone (optional)","width":100} /-->

<!-- wp:jetpack/field-textarea {"label":"Anything else I should know?"} /-->

<!-- wp:jetpack/button {"element":"button","text":"Post it to Leon"} /--></div>
<!-- /wp:jetpack/contact-form --></div>
<!-- /wp:group -->

<!-- wp:group {"anchor":"photo","className":"form-block","layout":{"type":"default"}} -->
<div id="photo" class="wp-block-group form-block"><!-- wp:paragraph {"className":"hand-note postcard__dear","textColor":"navy"} -->
<p class="hand-note postcard__dear has-navy-color has-text-color">Dear Leon, can you draw us from a photo?</p>
<!-- /wp:paragraph -->

<!-- wp:jetpack/contact-form {"subject":"New photo caricature enquiry from the website"} -->
<div class="wp-block-jetpack-contact-form"><!-- wp:jetpack/field-name {"label":"Your name","required":true,"width":50} /-->

<!-- wp:jetpack/field-email {"label":"Email","required":true,"width":50} /-->

<!-- wp:jetpack/field-select {"label":"How many people in the drawing?","required":true,"options":["1","2","3","4","5 or more"],"width":50} /-->

<!-- wp:jetpack/field-select {"label":"Black and white or colour?","options":["Black and white","Colour","Not sure yet"],"width":50} /-->

<!-- wp:jetpack/field-select {"label":"Hand-drawn on A3 paper or digital?","options":["Hand-drawn on A3 paper","Digital file","Not sure yet"],"width":50} /-->

<!-- wp:jetpack/field-date {"label":"When would you like to receive it?","width":50} /-->

<!-- wp:jetpack/field-checkbox-multiple {"label":"Extras (optional)","options":["Custom outfit","Body","Background","Theme"]} /-->

<!-- wp:jetpack/field-text {"label":"Delivery area for posted artworks (suburb and state)","width":100} /-->

<!-- wp:jetpack/field-file {"label":"Photos of each face (optional, up to 3)"} /-->

<!-- wp:jetpack/field-textarea {"label":"Tell me about the people and the occasion. No photos to hand? Send them when I reply."} /-->

<!-- wp:jetpack/button {"element":"button","text":"Post it to Leon"} /--></div>
<!-- /wp:jetpack/contact-form --></div>
<!-- /wp:group -->

<!-- wp:group {"anchor":"other","className":"form-block","layout":{"type":"default"}} -->
<div id="other" class="wp-block-group form-block"><!-- wp:paragraph {"className":"hand-note postcard__dear","textColor":"navy"} -->
<p class="hand-note postcard__dear has-navy-color has-text-color">Dear Leon, I have a question&#8230;</p>
<!-- /wp:paragraph -->

<!-- wp:jetpack/contact-form {"subject":"New question from the website"} -->
<div class="wp-block-jetpack-contact-form"><!-- wp:jetpack/field-name {"label":"Your name","required":true,"width":50} /-->

<!-- wp:jetpack/field-email {"label":"Email","required":true,"width":50} /-->

<!-- wp:jetpack/field-textarea {"label":"What can I help with?","required":true} /-->

<!-- wp:jetpack/button {"element":"button","text":"Post it to Leon"} /--></div>
<!-- /wp:jetpack/contact-form --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"36%","className":"postcard__address"} -->
<div class="wp-block-column postcard__address" style="flex-basis:36%"><!-- wp:group {"className":"postcard__top","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between","verticalAlignment":"top"}} -->
<div class="wp-block-group postcard__top"><!-- wp:paragraph {"className":"postmark"} -->
<p class="postmark">Melbourne VIC<br>Drawn by Leon</p>
<!-- /wp:paragraph -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","className":"postcard__stamp"} -->
<figure class="wp-block-image size-large postcard__stamp"><img src="<?php echo artist_portfolio_image( 'brand/leon-mascot.webp' ); ?>" alt="Stamp with Leon's self-caricature"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">To</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"address-lines"} -->
<ul class="wp-block-list address-lines"><!-- wp:list-item -->
<li>Leon, the guy with the marker</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="mailto:leon.caricature@gmail.com">leon.caricature@gmail.com</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="tel:+61466532313">0466 532 313</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Melbourne, VIC</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:paragraph {"fontSize":"small","style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<p class="has-small-font-size" style="margin-top:var(--wp--preset--spacing--40)">Email, call or send a message, whichever suits you. Paper portraits can be posted to you.</p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"iconColor":"navy","iconColorValue":"#12418A","iconBackgroundColor":"yellow","iconBackgroundColorValue":"#FFC72C"} -->
<ul class="wp-block-social-links has-icon-color has-icon-background-color"><!-- wp:social-link {"url":"https://www.instagram.com/leon.caricature","service":"instagram"} /-->

<!-- wp:social-link {"url":"https://www.facebook.com/leon.caricature","service":"facebook"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"doodle-drop","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull doodle-drop"><!-- wp:paragraph {"align":"center","className":"hand-note is-small doodle-drop__note","textColor":"navy-soft"} -->
<p class="has-text-align-center hand-note is-small doodle-drop__note has-navy-soft-color has-text-color">thanks for stopping by! (poke the doodles)</p>
<!-- /wp:paragraph -->

<!-- wp:group {"align":"full","className":"doodle-drop__pile","layout":{"type":"default"}} -->
<div class="wp-block-group alignfull doodle-drop__pile"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-paper.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-marker.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-easel.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-palette.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-wedding.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-birthday.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-community.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-photo.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-photo-upload.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-contact.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-speech.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-pencil.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-gift.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-crayons.webp' ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full"} -->
<figure class="wp-block-image size-full"><img src="<?php echo artist_portfolio_doodle( 'icons/leon-brush.webp' ); ?>" alt=""/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
