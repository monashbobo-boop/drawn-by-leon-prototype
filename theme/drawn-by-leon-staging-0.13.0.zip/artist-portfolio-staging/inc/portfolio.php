<?php
/**
 * Portfolio straight from the Media Library.
 *
 * Every image in the Media Library can be given one or more "Portfolio categories"
 * (Media > Portfolio categories, or the field on each image). The shortcode
 * [leon_portfolio] (used on the Portfolio page) shows one filter button per
 * category that has images, plus "All", and one gallery per category.
 *
 * - Category order = the order the categories were created in. The first one opens first.
 * - Inside a category the newest upload comes first.
 * - The image's Caption shows on hover; its Alt text is used for screen readers.
 * - Wide images (wider than tall) are marked "is-landscape" so a screenful is all wide or all upright.
 *
 * @package ArtistPortfolio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const ARTIST_PORTFOLIO_TAX = 'portfolio_category';

add_action(
	'init',
	function () {
		register_taxonomy(
			ARTIST_PORTFOLIO_TAX,
			'attachment',
			array(
				'labels'                => array(
					'name'          => __( 'Portfolio categories', 'artist-portfolio' ),
					'singular_name' => __( 'Portfolio category', 'artist-portfolio' ),
					'menu_name'     => __( 'Portfolio categories', 'artist-portfolio' ),
					'add_new_item'  => __( 'Add portfolio category', 'artist-portfolio' ),
					'edit_item'     => __( 'Edit portfolio category', 'artist-portfolio' ),
					'search_items'  => __( 'Search portfolio categories', 'artist-portfolio' ),
				),
				'public'                => false,
				'show_ui'               => true,
				'show_admin_column'     => true,
				'show_in_rest'          => true,
				'rest_base'             => 'portfolio-categories',
				'hierarchical'          => true,
				'query_var'             => false,
				'rewrite'               => false,
				'update_count_callback' => '_update_generic_term_count',
			)
		);
	}
);

/**
 * Block markup for one image block (rendered later by do_blocks, so the lightbox works).
 */
function artist_portfolio_image_block( $id ) {
	$meta    = wp_get_attachment_metadata( $id );
	$src     = wp_get_attachment_image_url( $id, 'large' );
	if ( ! $src ) {
		return '';
	}
	$alt     = get_post_meta( $id, '_wp_attachment_image_alt', true );
	$caption = wp_get_attachment_caption( $id );
	$wide    = ! empty( $meta['width'] ) && ! empty( $meta['height'] ) && $meta['width'] > $meta['height'] * 1.05;
	$attrs   = array(
		'id'              => $id,
		'sizeSlug'        => 'large',
		'linkDestination' => 'none',
	);
	$class   = 'wp-block-image size-large';
	if ( $wide ) {
		$attrs['className'] = 'is-landscape';
		$class             .= ' is-landscape';
	}
	$html  = '<!-- wp:image ' . wp_json_encode( $attrs ) . ' -->';
	$html .= '<figure class="' . esc_attr( $class ) . '"><img src="' . esc_url( $src ) . '" alt="' . esc_attr( $alt ) . '" class="wp-image-' . (int) $id . '"/>';
	if ( $caption ) {
		$html .= '<figcaption class="wp-element-caption">' . esc_html( $caption ) . '</figcaption>';
	}
	$html .= '</figure><!-- /wp:image -->';
	return $html;
}

add_shortcode(
	'leon_portfolio',
	function () {
		$terms = get_terms(
			array(
				'taxonomy'   => ARTIST_PORTFOLIO_TAX,
				'hide_empty' => true,
				'orderby'    => 'term_id',
				'order'      => 'ASC',
			)
		);
		if ( is_wp_error( $terms ) || ! $terms ) {
			return '';
		}

		$buttons = '<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#all">' . esc_html__( 'All', 'artist-portfolio' ) . '</a></div><!-- /wp:button -->';
		$grids   = '';
		foreach ( $terms as $term ) {
			$ids = get_posts(
				array(
					'post_type'      => 'attachment',
					'post_status'    => 'inherit',
					'post_mime_type' => 'image',
					'posts_per_page' => 300,
					'orderby'        => array(
						'menu_order' => 'ASC',
						'date'       => 'DESC',
					),
					'fields'         => 'ids',
					'tax_query'      => array(
						array(
							'taxonomy' => ARTIST_PORTFOLIO_TAX,
							'field'    => 'term_id',
							'terms'    => $term->term_id,
						),
					),
				)
			);
			if ( ! $ids ) {
				continue;
			}
			$slug     = sanitize_title( $term->slug );
			$buttons .= '<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#' . esc_attr( $slug ) . '">' . esc_html( $term->name ) . '</a></div><!-- /wp:button -->';
			$grids   .= '<!-- wp:gallery {"columns":3,"linkTo":"none","sizeSlug":"large","anchor":"' . esc_attr( $slug ) . '","className":"is-style-masonry"} -->';
			$grids   .= '<figure id="' . esc_attr( $slug ) . '" class="wp-block-gallery has-nested-images columns-3 is-cropped is-style-masonry">';
			foreach ( $ids as $id ) {
				$grids .= artist_portfolio_image_block( $id );
			}
			$grids .= '</figure><!-- /wp:gallery -->';
		}

		$first = sanitize_title( $terms[0]->slug );
		$out   = '<!-- wp:buttons {"className":"work-filter","align":"wide"} --><div class="wp-block-buttons alignwide work-filter" data-default="' . esc_attr( $first ) . '">' . $buttons . '</div><!-- /wp:buttons -->';
		$out  .= '<!-- wp:group {"align":"wide","className":"works-grid","style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}},"layout":{"type":"default"}} --><div class="wp-block-group alignwide works-grid" style="margin-top:var(--wp--preset--spacing--40)">' . $grids . '</div><!-- /wp:group -->';
		return do_blocks( $out );
	}
);
